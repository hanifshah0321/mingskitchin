<div class="card-body" id="schedule">
    <?php ($data=[]); ?>
    <?php
    foreach ($schedules as $schedule)
    {
        $data[$schedule->day][]=['id'=>$schedule->id,'start_time'=>$schedule->opening_time, 'end_time'=>$schedule->closing_time];
    }
    ?>
    <div class="my-2 p-1 border rounded">
        <span class="btn btn-dark"><?php echo e(translate('monday')); ?> :</span>
        <?php if(isset($data['1']) && count($data['1'])): ?>
            <?php $__currentLoopData = $data['1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="btn btn-sm btn-outline-dark m-1 disabled"><?php echo e(date(config('time_format'), strtotime($day['start_time']))); ?> - <?php echo e(date(config('time_format'), strtotime($day['end_time']))); ?> <span class="badge badge-danger rounded-circle cursor-pointer" onclick="delete_schedule('<?php echo e(route('admin.business-settings.restaurant.time_schedule_remove',['schedule_id'=>$day['id']])); ?>')">X</span></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <span class="btn btn-sm btn-outline-danger m-1 disabled"><?php echo e(translate('Offday')); ?></span>
        <?php endif; ?>
        <span class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-dayid="1" data-day="<?php echo e(translate('monday')); ?>"><i class="tio-add"></i></span>
    </div>

    <div class="my-2 p-1 border rounded">
        <span class="btn btn-dark"><?php echo e(translate('tuesday')); ?> :</span>
        <?php if(isset($data['2']) && count($data['2'])): ?>
            <?php $__currentLoopData = $data['2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="btn btn-sm btn-outline-dark m-1 disabled"><?php echo e(date(config('time_format'), strtotime($day['start_time']))); ?> - <?php echo e(date(config('time_format'), strtotime($day['end_time']))); ?> <span class="badge badge-danger rounded-circle cursor-pointer" onclick="delete_schedule('<?php echo e(route('admin.business-settings.restaurant.time_schedule_remove',['schedule_id'=>$day['id']])); ?>')">X</span></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <span class="btn btn-sm btn-outline-danger m-1 disabled"><?php echo e(translate('Offday')); ?></span>
        <?php endif; ?>
        <span class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-dayid="2" data-day="<?php echo e(translate('tuesday')); ?>"><i class="tio-add"></i></span>
    </div>

    <div class="my-2 p-1 border rounded">
        <span class="btn btn-dark"><?php echo e(translate('wednesday')); ?> :</span>
        <?php if(isset($data['3']) && count($data['3'])): ?>
            <?php $__currentLoopData = $data['3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="btn btn-sm btn-outline-dark m-1 disabled"><?php echo e(date(config('time_format'), strtotime($day['start_time']))); ?> - <?php echo e(date(config('time_format'), strtotime($day['end_time']))); ?> <span class="badge badge-danger rounded-circle cursor-pointer" onclick="delete_schedule('<?php echo e(route('admin.business-settings.restaurant.time_schedule_remove',['schedule_id'=>$day['id']])); ?>')">X</span></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <span class="btn btn-sm btn-outline-danger m-1 disabled"><?php echo e(translate('Offday')); ?></span>
        <?php endif; ?>
        <span class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-dayid="3" data-day="<?php echo e(translate('wednesday')); ?>"><i class="tio-add"></i></span>
    </div>

    <div class="my-2 p-1 border rounded">
        <span class="btn btn-dark"><?php echo e(translate('thirsday')); ?> :</span>
        <?php if(isset($data['4']) && count($data['4'])): ?>
            <?php $__currentLoopData = $data['4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="btn btn-sm btn-outline-dark m-1 disabled"><?php echo e(date(config('time_format'), strtotime($day['start_time']))); ?> - <?php echo e(date(config('time_format'), strtotime($day['end_time']))); ?> <span class="badge badge-danger rounded-circle cursor-pointer" onclick="delete_schedule('<?php echo e(route('admin.business-settings.restaurant.time_schedule_remove',['schedule_id'=>$day['id']])); ?>')">X</span></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <span class="btn btn-sm btn-outline-danger m-1 disabled"><?php echo e(translate('Offday')); ?></span>
        <?php endif; ?>
        <span class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-dayid="4" data-day="<?php echo e(translate('thirsday')); ?>"><i class="tio-add"></i></span>
    </div>

    <div class="my-2 p-1 border rounded">
        <span class="btn btn-dark"><?php echo e(translate('friday')); ?> :</span>
        <?php if(isset($data['5']) && count($data['5'])): ?>
            <?php $__currentLoopData = $data['5']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="btn btn-sm btn-outline-dark m-1 disabled"><?php echo e(date(config('time_format'), strtotime($day['start_time']))); ?> - <?php echo e(date(config('time_format'), strtotime($day['end_time']))); ?> <span class="badge badge-danger rounded-circle cursor-pointer" onclick="delete_schedule('<?php echo e(route('admin.business-settings.restaurant.time_schedule_remove',['schedule_id'=>$day['id']])); ?>')">X</span></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <span class="btn btn-sm btn-outline-danger m-1 disabled"><?php echo e(translate('Offday')); ?></span>
        <?php endif; ?>
        <span class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-dayid="5" data-day="<?php echo e(translate('friday')); ?>"><i class="tio-add"></i></span>
    </div>

    <div class="my-2 p-1 border rounded">
        <span class="btn btn-dark"><?php echo e(translate('saturday')); ?> :</span>
        <?php if(isset($data['6']) && count($data['6'])): ?>
            <?php $__currentLoopData = $data['6']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="btn btn-sm btn-outline-dark m-1 disabled"><?php echo e(date(config('time_format'), strtotime($day['start_time']))); ?> - <?php echo e(date(config('time_format'), strtotime($day['end_time']))); ?> <span class="badge badge-danger rounded-circle cursor-pointer" onclick="delete_schedule('<?php echo e(route('admin.business-settings.restaurant.time_schedule_remove',['schedule_id'=>$day['id']])); ?>')">X</span></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <span class="btn btn-sm btn-outline-danger m-1 disabled"><?php echo e(translate('Offday')); ?></span>
        <?php endif; ?>
        <span class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-dayid="6" data-day="<?php echo e(translate('saturday')); ?>"><i class="tio-add"></i></span>
    </div>

    <div class="my-2 p-1 border rounded">
        <span class="btn btn-dark"><?php echo e(translate('sunday')); ?> :</span>
        <?php if(isset($data['0']) && count($data['0'])): ?>
            <?php $__currentLoopData = $data['0']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="btn btn-sm btn-outline-dark m-1 disabled"><?php echo e(date(config('time_format'), strtotime($day['start_time']))); ?> - <?php echo e(date(config('time_format'), strtotime($day['end_time']))); ?> <span class="badge badge-danger rounded-circle cursor-pointer" onclick="delete_schedule('<?php echo e(route('admin.business-settings.restaurant.time_schedule_remove',['schedule_id'=>$day['id']])); ?>')">X</span></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <span class="btn btn-sm btn-outline-danger m-1 disabled"><?php echo e(translate('Offday')); ?></span>
        <?php endif; ?>
        <span class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-dayid="0" data-day="<?php echo e(translate('sunday')); ?>"><i class="tio-add"></i></span>
    </div>
</div>
<?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/business-settings/partials/_schedule.blade.php ENDPATH**/ ?>