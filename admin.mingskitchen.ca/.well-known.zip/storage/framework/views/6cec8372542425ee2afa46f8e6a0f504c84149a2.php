<?php $__env->startSection('title', translate('Settings')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <script src="https://use.fontawesome.com/74721296a6.js"></script>
    <link rel="stylesheet"
          href=
          "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .input-icons i {
            position: absolute;
            cursor: pointer;
            /*text-align: right*/
            background-color: #F8FAFD;
            border: #E7EAF3 1px solid;
        }

        .input-icons {
            width: 100%;
            margin-bottom: 10px;
        }

        .icon {
            padding: 10px;
            min-width: 40px;
        }

        .input-field {
            width: 94%;
            padding: 10px;
            text-align: center;
            border-right-style: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(translate('Clean Database')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <div class="alert alert-danger mx-2" role="alert">
                    <?php echo e(translate('This_page_contains_sensitive_information.Make_sure_before_changing.')); ?>

                </div>
                <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                    <form action="<?php echo e(route('admin.business-settings.web-app.system-setup.clean-db')); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3">
                                    <div class="form-group form-check">
                                        <input type="checkbox" name="tables[]" value="<?php echo e($table); ?>"
                                               class="form-check-input"
                                               id="business_section_<?php echo e($key); ?>">
                                        <label class="form-check-label text-dark"
                                               style="<?php echo e(Session::get('direction') === "rtl" ? 'margin-right: 1.25rem;' : ''); ?>;"
                                               for="business_section_<?php echo e($key); ?>"><?php echo e(Str::limit($table, 20)); ?></label>
                                        <span class="badge-pill badge-secondary mx-2"><?php echo e($rows[$key]); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <hr>
                        <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>"
                                onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>"
                                class="btn btn-primary mb-2"><?php echo e(translate('Clear')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        $(document).ready(function () {
            $("#purchase_code_div").click(function () {
                var type = $('#purchase_code').get(0).type;
                if (type === 'password') {
                    $('#purchase_code').get(0).type = 'text';
                } else if (type === 'text') {
                    $('#purchase_code').get(0).type = 'password';
                }
            });
        })
    </script>

    <script>
        $("form").on('submit',function(e) {
            e.preventDefault();
            Swal.fire({
                title: '<?php echo e(translate('Are you sure?')); ?>',
                text: "<?php echo e(translate('Sensitive_data! Make_sure_before_changing.')); ?>",
                type: 'warning',
                showCancelButton: true,
                cancelButtonColor: 'default',
                confirmButtonColor: '#FC6A57',
                cancelButtonText: 'No',
                confirmButtonText: 'Yes',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    this.submit();
                }else{
                    e.preventDefault();
                    toastr.success("<?php echo e(translate('Cancelled')); ?>");
                    location.reload();
                }
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/business-settings/db-index.blade.php ENDPATH**/ ?>