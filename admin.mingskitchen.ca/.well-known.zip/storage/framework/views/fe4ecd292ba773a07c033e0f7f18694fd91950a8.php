<?php $__env->startSection('title', translate('Membership Plan List')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('public/assets/back-end')); ?>/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(translate('Dashboard')); ?></a></li>
            <li class="breadcrumb-item" aria-current="page">Membership</li>
            <li class="breadcrumb-item" aria-current="page"><?php echo e(translate('List')); ?></li>
        </ol>
    </nav>

    <div class="row" style="margin-top: 20px">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header flex-between">
                    <div class="">
                        <h5>Membership Plan
                            <span style="color: red; padding: 0 .4375rem;">
                            (<?php echo e($em->total()); ?>)</span>
                        </h5>
                    </div>
                    <div class="flex-end">
                        <div class="mx-2">
                            <form action="<?php echo e(url()->current()); ?>" method="GET">
                                <div class="input-group">
                                    <input id="datatableSearch_" type="search" name="search"
                                           class="form-control"
                                           placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                           value="<?php echo e($search); ?>" required autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div>
                            <a href="<?php echo e(route('admin.membership.add-new')); ?>" class="btn btn-primary  float-right">
                                <i class="tio-add-circle"></i>
                                <span class="text"><?php echo e(translate('Add')); ?> <?php echo e(translate('New')); ?></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body" style="padding: 0">
                    <div class="table-responsive">
                        <table id="datatable" style="text-align: <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>;"
                               class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                               style="width: 100%">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('SL')); ?>#</th>
                                <th>Title</th>
                                <th>Price</th>
                                <th>Duration</th>
                                <th>Discount</th>
                                <th>Descrition</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $em; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                                <tr>
                                    <th scope="row"><?php echo e($k+1); ?></th>
                                    <td class="text-capitalize"><?php echo e($e['title']); ?></td>
                                    <td >
                                      <?php echo e($e['price']); ?>

                                    </td>
                                     <td><?php echo e($e['duration']); ?></td>
                                     <td><?php echo e($e['discount']); ?></td>
                                     <td><?php echo e($e['des']); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.membership.update',[$e['id']])); ?>"
                                           class="btn btn-primary btn-sm"
                                           title="<?php echo e(translate('Edit')); ?>">
                                           <i class="tio-edit"></i>
                                        </a>
                                    </td>
                                </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <?php echo e($em->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('public/assets/back-end')); ?>/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('public/assets/back-end')); ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <!-- Page level custom scripts -->
    <script>
        // Call the dataTables jQuery plugin
        $(document).ready(function () {
            $('#dataTable').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ming's\resources\views/admin-views/membership/list.blade.php ENDPATH**/ ?>