<?php $__env->startSection('title', translate('Settings')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <style>

        .switch {
            position: relative;
            display: inline-block;
            width: 48px;
            height: 23px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            -webkit-transition: .4s;
            transition: .4s;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 15px;
            width: 15px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            -webkit-transition: .4s;
            transition: .4s;
        }

        input:checked + .slider {
            background-color: #FC6A57;
        }

        input:focus + .slider {
            box-shadow: 0 0 1px #FC6A57;
        }

        input:checked + .slider:before {
            -webkit-transform: translateX(26px);
            -ms-transform: translateX(26px);
            transform: translateX(26px);
        }

        /* Rounded sliders */
        .slider.round {
            border-radius: 34px;
        }

        .slider.round:before {
            border-radius: 50%;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(translate('App Settings')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->

        <div class="row" style="padding-bottom: 20px">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h2 class="text-center"><?php echo e(translate('Android')); ?></h2>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('play_store_config')); ?>
                        <form
                            action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.web-app.system-setup.app_setting',['platform' => 'android']):'javascript:'); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mt-4">
                                <div class="my-2">
                                    <label
                                        class="text-dark font-weight-bold"><?php echo e(translate('Enable download link for web footer')); ?></label>
                                    <label class="switch ml-3 ">
                                        <input type="checkbox" class="status" name="play_store_status"
                                               value="1" <?php echo e((isset($config) && $config['status']==1)?'checked':''); ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </div>

                                <div class="my-2">
                                    <label class="text-dark"
                                           for="app_store_link"><?php echo e(translate('Download link')); ?>

                                    </label>
                                    <input type="text" id="play_store_link" name="play_store_link"
                                           value="<?php echo e($config['link']??''); ?>" class="form-control" placeholder="">
                                </div>

                                <div class="my-2">
                                    <label class="text-dark"
                                           for="android_min_version"><?php echo e(translate('Minimum version for force update')); ?>

                                        <i class="tio-info text-danger" data-toggle="tooltip" data-placement="right"
                                           title="<?php echo e(\App\CentralLogics\translate("If there is any update available in the admin panel and for that, the previous user app will not work, you can force the customer from here by providing the minimum version for force update. That means if a customer has an app below this version the customers must need to update the app first. If you don't need a force update just insert here zero (0) and ignore it.")); ?>"></i>
                                    </label>
                                    <input type="number" min="0" step=".1" id="android_min_version" name="android_min_version"
                                           value="<?php echo e($config['min_version']??''); ?>" class="form-control"
                                           placeholder="<?php echo e(translate('EX: 4.0')); ?>">
                                </div>

                            </div>

                            <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>"
                                    onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>"
                                    class="btn btn-primary mb-2"><?php echo e(translate('save')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mt-2 mt-md-0">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h2 class="text-center"><?php echo e(translate('IOS')); ?></h2>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('app_store_config')); ?>
                        <form
                            action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.web-app.system-setup.app_setting',['platform' => 'ios']):'javascript:'); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mt-4">
                                <div class="my-2">
                                    <label
                                        class="text-dark font-weight-bold"><?php echo e(translate('Enable download link for web footer')); ?></label>
                                    <label class="switch ml-3 ">
                                        <input type="checkbox" class="status" name="app_store_status"
                                               value="1" <?php echo e((isset($config) && $config['status']==1)?'checked':''); ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </div>

                                <div class="my-2">
                                    <label class="text-dark"
                                           for="app_store_link"><?php echo e(translate('Download link')); ?>

                                    </label>
                                    <input type="text" id="app_store_link" name="app_store_link"
                                           value="<?php echo e($config['link']??''); ?>" class="form-control" placeholder="">
                                </div>

                                <div class="my-2">
                                    <label class="text-dark"
                                           for="ios_min_version"><?php echo e(translate('Minimum version for force update')); ?>

                                        <i class="tio-info text-danger" data-toggle="tooltip" data-placement="right"
                                           title="<?php echo e(\App\CentralLogics\translate("If there is any update available in the admin panel and for that, the previous user app will not work, you can force the customer from here by providing the minimum version for force update. That means if a customer has an app below this version the customers must need to update the app first. If you don't need a force update just insert here zero (0) and ignore it.")); ?>"></i>
                                    </label>
                                    <input type="number" min="0" step=".1" id="ios_min_version" name="ios_min_version"
                                           value="<?php echo e($config['min_version']??''); ?>" class="form-control"
                                           placeholder="<?php echo e(translate('EX: 4.0')); ?>">
                                </div>

                            </div>

                            <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>"
                                    onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>"
                                    class="btn btn-primary mb-2"><?php echo e(translate('save')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/business-settings/app-setting-index.blade.php ENDPATH**/ ?>