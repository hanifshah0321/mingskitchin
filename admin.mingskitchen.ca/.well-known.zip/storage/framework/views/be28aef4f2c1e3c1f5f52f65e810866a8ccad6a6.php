<?php $__env->startSection('title', translate('Update Branch')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title text-capitalize"><i
                            class="tio-edit"></i> <?php echo e(translate('Branch Update')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <?php ($branch_count=\App\Model\Branch::count()); ?>
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(route('admin.branch.update',[$branch['id']])); ?>" method="post"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('name')); ?></label>
                                <input type="text" name="name" value="<?php echo e($branch['name']); ?>" class="form-control"
                                       placeholder="<?php echo e(translate('New branch')); ?>"
                                       maxlength="255" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('email')); ?></label>
                                <input type="email" name="email" value="<?php echo e($branch['email']); ?>" class="form-control"
                                       placeholder="<?php echo e(translate('EX : example@example.com')); ?>"
                                       maxlength="255" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-5">
                            <div class="form-group">
                                <label class="input-label" for=""><?php echo e(translate('latitude')); ?></label>
                                <input type="number" name="latitude" value="<?php echo e($branch['latitude']); ?>" class="form-control"
                                       placeholder="<?php echo e(translate('Ex : -132.44442')); ?>" maxlength="255"
                                       step="any" <?php echo e($branch_count>1?'required':''); ?>>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group">
                                <label class="input-label" for=""><?php echo e(translate('longitude')); ?></label>
                                <input type="number" name="longitude" value="<?php echo e($branch['longitude']); ?>"
                                       class="form-control" maxlength="255" step="any"
                                       placeholder="<?php echo e(translate('Ex : 94.233')); ?>"
                                    <?php echo e($branch_count>1?'required':''); ?>>
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label class="input-label" for="">
                                    <i class="tio-info-outined"
                                       data-toggle="tooltip"
                                       data-placement="top"
                                       title="<?php echo e(translate('This value is the radius from your restaurant location, and customer can order food inside  the circle calculated by this radius.')); ?>"></i>
                                    <?php echo e(translate('coverage (km)')); ?>

                                </label>
                                <input type="number" name="coverage" min="1" value="<?php echo e($branch['coverage']); ?>" max="1000"
                                       class="form-control" placeholder="<?php echo e(translate('Ex : 3')); ?>"
                                    <?php echo e($branch_count>1?'required':''); ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label" for=""><?php echo e(translate('address')); ?></label>
                                <input type="text" name="address" value="<?php echo e($branch['address']); ?>" class="form-control"
                                       placeholder="" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('password')); ?> <span
                                        class="" style="color: red;font-size: small">* ( <?php echo e(translate('input if you want to reset.')); ?> )</span></label>
                                <input type="text" name="password" class="form-control" placeholder="">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><?php echo e(translate('Branch Image')); ?></label><small style="color: red">* ( <?php echo e(translate('ratio')); ?> 1:1 )</small>
                        <div class="custom-file">
                            <input type="file" name="image" id="customFileEg1" class="custom-file-input" value="<?php echo e($branch['image']); ?>"
                                   accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                            <label class="custom-file-label" for="customFileEg1"><?php echo e(translate('Choose File')); ?></label>
                        </div>
                        <div class="text-center mt-2">
                            <img style="height: 200px;border: 1px solid; border-radius: 10px;" id="viewer"
                                 src="<?php echo e(asset('storage/app/public/branch')); ?>/<?php echo e($branch['image']); ?>"
                                 onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                 alt="branch image"/>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(translate('update')); ?></button>
                </form>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/branch/edit.blade.php ENDPATH**/ ?>