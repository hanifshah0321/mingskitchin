<?php $__env->startSection('title', translate('Order Details')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header d-print-none">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-no-gutter">
                            <li class="breadcrumb-item">
                                <a class="breadcrumb-link"
                                   href="<?php echo e(route('admin.orders.list',['status'=>'all'])); ?>">
                                    Orders
                                </a>
                            </li>
                            <li class="breadcrumb-item active"
                                aria-current="page"><?php echo e(translate('order')); ?> <?php echo e(translate('details')); ?></li>
                        </ol>
                    </nav>

                    <div class="d-sm-flex align-items-sm-center">
                        <h1 class="page-header-title"><?php echo e(translate('order')); ?> #<?php echo e($order['id']); ?></h1>

                        <?php if($order['payment_status']=='paid'): ?>
                            <span class="badge badge-soft-success ml-sm-3">
                                <span class="legend-indicator bg-success"></span><?php echo e(translate('paid')); ?>

                            </span>
                        <?php else: ?>
                            <span class="badge badge-soft-danger ml-sm-3">
                                <span class="legend-indicator bg-danger"></span><?php echo e(translate('unpaid')); ?>

                            </span>
                        <?php endif; ?>

                        <?php if($order['order_status']=='pending'): ?>
                            <span class="badge badge-soft-info ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-info text"></span><?php echo e(translate('pending')); ?>

                            </span>
                        <?php elseif($order['order_status']=='confirmed'): ?>
                            <span class="badge badge-soft-info ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-info"></span><?php echo e(translate('confirmed')); ?>

                            </span>
                        <?php elseif($order['order_status']=='processing'): ?>
                            <span class="badge badge-soft-warning ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-warning"></span><?php echo e(translate('processing')); ?>

                            </span>
                        <?php elseif($order['order_status']=='out_for_delivery'): ?>
                            <span class="badge badge-soft-warning ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-warning"></span><?php echo e(translate('out_for_delivery')); ?>

                            </span>
                        <?php elseif($order['order_status']=='delivered'): ?>
                            <span class="badge badge-soft-success ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-success"></span><?php echo e(translate('delivered')); ?>

                            </span>
                        <?php else: ?>
                            <span class="badge badge-soft-danger ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-danger"></span><?php echo e(str_replace('_',' ',$order['order_status'])); ?>

                            </span>
                        <?php endif; ?>
                        <span class="ml-2 ml-sm-3">
                           <i class="tio-date-range"></i> <?php echo e(date('d M Y',strtotime($order['created_at']))); ?> <?php echo e(date(config('time_format'), strtotime($order['created_at']))); ?>

                        </span>
                        <?php if($order['delivery_date'] > \Carbon\Carbon::now()->format('Y-m-d')): ?>
                            <span class="ml-2 ml-sm-3 badge badge-soft-success">
                               <i class="tio-time"></i> <?php echo e(translate('scheduled')); ?> : <?php echo e(date('d-M-Y',strtotime($order['delivery_date']))); ?> <?php echo e(date(config('time_format'), strtotime($order['delivery_time']))); ?>

                            </span>
                        <?php else: ?>
                            <span class="ml-2 ml-sm-3 badge badge-soft-success">
                               <i class="tio-time"></i> <?php echo e(date('d-M-Y',strtotime($order['delivery_date']))); ?> <?php echo e(date(config('time_format'), strtotime($order['delivery_time']))); ?>

                            </span>
                        <?php endif; ?>

                        
                        <?php if($order['order_type'] != 'pos' && $order['order_type'] != 'take_away' && ($order['order_status'] != DELIVERED && $order['order_status'] != RETURNED && $order['order_status'] != CANCELED && $order['order_status'] != FAILED)): ?>
                            <span class="ml-2 ml-sm-3 ">
                                <i class="tio-timer d-none" id="timer-icon"></i>
                                <span id="counter" class="text-info"></span>
                                <i class="tio-edit p-2 d-none" id="edit-icon" style="cursor: pointer;" data-toggle="modal" data-target="#counter-change" data-whatever="@mdo"></i>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="mt-2">
                        <a class="text-body mr-3"
                           href=<?php echo e(route('admin.orders.generate-invoice',[$order['id']])); ?>>
                            <i class="tio-print mr-1"></i> <?php echo e(translate('print')); ?> <?php echo e(translate('invoice')); ?>

                        </a>

                        <!-- Unfold -->
                        <?php if($order['order_type']!='take_away' && $order['order_type'] != 'pos'): ?>
                            <div class="hs-unfold">
                                <select class="form-control" name="delivery_man_id"
                                        onchange="addDeliveryMan(this.value)">
                                    <option
                                        value="0"><?php echo e(translate('select')); ?> <?php echo e(translate('deliveryman')); ?></option>
                                    <?php $__currentLoopData = \App\Model\DeliveryMan::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliveryMan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($deliveryMan['id']); ?>" <?php echo e($order['delivery_man_id']==$deliveryMan['id']?'selected':''); ?>>
                                            <?php echo e($deliveryMan['f_name'].' '.$deliveryMan['l_name']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="hs-unfold ml-1">
                                <?php if($order['order_status']=='out_for_delivery'): ?>
                                    <?php ($origin=\App\Model\DeliveryHistory::where(['deliveryman_id'=>$order['delivery_man_id'],'order_id'=>$order['id']])->first()); ?>
                                    <?php ($current=\App\Model\DeliveryHistory::where(['deliveryman_id'=>$order['delivery_man_id'],'order_id'=>$order['id']])->latest()->first()); ?>
                                    <?php if(isset($origin)): ?>
                                        
                                        <a class="btn btn-outline-primary" target="_blank"
                                           title="Delivery Boy Last Location" data-toggle="tooltip" data-placement="top"
                                           href="https://www.google.com/maps/dir/?api=1&origin=<?php echo e($origin['latitude']); ?>,<?php echo e($origin['longitude']); ?>&destination=<?php echo e($current['latitude']); ?>,<?php echo e($current['longitude']); ?>">
                                            <i class="tio-map"></i>
                                        </a>
                                    <?php else: ?>
                                        <a class="btn btn-outline-primary" href="javascript:" data-toggle="tooltip"
                                           data-placement="top" title="Waiting for location...">
                                            <i class="tio-map"></i>
                                        </a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a class="btn btn-outline-dark" href="javascript:" onclick="last_location_view()"
                                       data-toggle="tooltip" data-placement="top"
                                       title="Only available when order is out for delivery!">
                                        <i class="tio-map"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <div class="hs-unfold ml-1">
                            <h5 class="text-capitalize">
                                <i class="tio-shop"></i>
                                <?php echo e(translate('branch')); ?> : <label
                                    class="badge badge-secondary"><?php echo e($order->branch?$order->branch->name:'Branch deleted!'); ?></label>
                            </h5>
                        </div>

                        <div class="hs-unfold float-right">
                            <?php if($order['order_type'] != 'pos'): ?>
                                <div class="dropdown">
                                    <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button"
                                            id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false">
                                        <?php echo e(translate('status')); ?>

                                    </button>
                                    <div class="dropdown-menu text-capitalize dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.status',['id'=>$order['id'],'order_status'=>'pending'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to pending ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('pending')); ?></a>
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.status',['id'=>$order['id'],'order_status'=>'confirmed'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to confirmed ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('confirmed')); ?></a>
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.status',['id'=>$order['id'],'order_status'=>'processing'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to processing ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('processing')); ?></a>
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.status',['id'=>$order['id'],'order_status'=>'out_for_delivery'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to out for delivery ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('out_for_delivery')); ?></a>
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.status',['id'=>$order['id'],'order_status'=>'delivered'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to delivered ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('delivered')); ?></a>
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.status',['id'=>$order['id'],'order_status'=>'returned'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to returned ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('returned')); ?></a>
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.status',['id'=>$order['id'],'order_status'=>'failed'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to failed ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('failed')); ?></a>
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.status',['id'=>$order['id'],'order_status'=>'canceled'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to canceled ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('canceled')); ?></a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="hs-unfold float-right pr-2">
                            <?php if($order['order_type'] != 'pos'): ?>
                                <div class="dropdown">
                                    <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button"
                                            id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false">
                                        <?php echo e(translate('payment')); ?>

                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.payment-status',['id'=>$order['id'],'payment_status'=>'paid'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to paid ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('paid')); ?></a>
                                        <a class="dropdown-item"
                                           onclick="route_alert('<?php echo e(route('admin.orders.payment-status',['id'=>$order['id'],'payment_status'=>'unpaid'])); ?>','<?php echo e(\App\CentralLogics\translate("Change status to unpaid ?")); ?>')"
                                           href="javascript:"><?php echo e(translate('unpaid')); ?></a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <!-- End Unfold -->
                    </div>
                </div>

                <div class="col-sm-auto">
                    <a class="btn btn-icon btn-sm btn-ghost-secondary rounded-circle mr-1"
                       href="<?php echo e(route('admin.orders.details',[$order['id']-1])); ?>"
                       data-toggle="tooltip" data-placement="top" title="Previous order">
                        <i class="tio-arrow-backward"></i>
                    </a>
                    <a class="btn btn-icon btn-sm btn-ghost-secondary rounded-circle"
                       href="<?php echo e(route('admin.orders.details',[$order['id']+1])); ?>" data-toggle="tooltip"
                       data-placement="top" title="Next order">
                        <i class="tio-arrow-forward"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- End Page Header -->

        <div class="row" id="printableArea">
            <div class="col-lg-<?php echo e($order->customer!=null ? 8 : 12); ?> mb-3 mb-lg-0">
                <!-- Card -->
                <div class="card mb-3 mb-lg-5">
                    <!-- Header -->
                    <div class="card-header" style="display: block!important;">
                        <div class="row">
                            <div class="col-12 pb-2 border-bottom">
                                <h4 class="card-header-title">
                                    <?php echo e(translate('order')); ?> <?php echo e(translate('details')); ?>

                                    <span
                                        class="badge badge-soft-dark rounded-circle ml-1"><?php echo e($order->details->count()); ?></span>
                                </h4>
                            </div>
                            <div class="col-6 pt-2">
                                <h6 style="color: #8a8a8a;">
                                    <?php echo e(translate('order')); ?> <?php echo e(translate('note')); ?> : <?php echo e($order['order_note']); ?>

                                </h6>
                            </div>
                            <div class="col-6 pt-2">
                                <div class="text-right">
                                    <h6 class="text-capitalize" style="color: #8a8a8a;">
                                        <?php echo e(translate('payment')); ?> <?php echo e(translate('method')); ?>

                                        : <?php echo e(str_replace('_',' ',$order['payment_method'])); ?>

                                    </h6>
                                    <h6 class="" style="color: #8a8a8a;">
                                        <?php if($order['transaction_reference']==null && $order['order_type']!='pos'): ?>
                                            <?php echo e(translate('reference')); ?> <?php echo e(translate('code')); ?> :
                                            <button class="btn btn-outline-primary btn-sm" data-toggle="modal"
                                                    data-target=".bd-example-modal-sm">
                                                <?php echo e(translate('add')); ?>

                                            </button>
                                        <?php elseif($order['order_type']!='pos'): ?>
                                            <?php echo e(translate('reference')); ?> <?php echo e(translate('code')); ?>

                                            : <?php echo e($order['transaction_reference']); ?>

                                        <?php endif; ?>
                                    </h6>
                                    <h6 class="text-capitalize"
                                        style="color: #8a8a8a;"><?php echo e(translate('order')); ?> <?php echo e(translate('type')); ?>

                                        : <label style="font-size: 10px"
                                                 class="badge badge-soft-primary"><?php echo e(str_replace('_',' ',$order['order_type'])); ?></label>
                                    </h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Header -->

                    <!-- Body -->
                    <div class="card-body">
                    <?php ($sub_total=0); ?>
                    <?php ($total_tax=0); ?>
                    <?php ($total_dis_on_pro=0); ?>
                    <?php ($add_ons_cost=0); ?>
                    <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($detail->product): ?>
                            <?php ($add_on_qtys=json_decode($detail['add_on_qtys'],true)); ?>
                            <!-- Media -->
                                <div class="media">
                                    <div class="avatar avatar-xl mr-3">
                                        <img class="img-fluid"
                                             src="<?php echo e(asset('storage/app/public/product')); ?>/<?php echo e($detail->product['image']); ?>"
                                             onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'"
                                             alt="Image Description">
                                    </div>

                                    <div class="media-body">
                                        <div class="row">
                                            <div class="col-md-6 mb-3 mb-md-0">
                                                <strong> <?php echo e($detail->product['name']); ?></strong><br>

                                                <?php if(count(json_decode($detail['variation'],true))>0): ?>
                                                    <strong><u><?php echo e(translate('variation')); ?> : </u></strong>
                                                    <?php $__currentLoopData = json_decode($detail['variation'],true)[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 =>$variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="font-size-sm text-body">
                                                            <span><?php echo e($key1); ?> :  </span>
                                                            <span class="font-weight-bold"><?php echo e($key1 == 'price' ?  Helpers::set_symbol($variation) : $variation); ?></span>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                                <?php $__currentLoopData = json_decode($detail['add_on_ids'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 =>$id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php ($addon=\App\Model\AddOn::find($id)); ?>
                                                    <?php if($key2==0): ?><strong><u><?php echo e(translate('addons')); ?>

                                                            : </u></strong><?php endif; ?>

                                                    <?php if($add_on_qtys==null): ?>
                                                        <?php ($add_on_qty=1); ?>
                                                    <?php else: ?>
                                                        <?php ($add_on_qty=$add_on_qtys[$key2]); ?>
                                                    <?php endif; ?>

                                                    <div class="font-size-sm text-body">
                                                        <span><?php echo e($addon['name']); ?> :  </span>
                                                        <span class="font-weight-bold">
                                                            <?php echo e($add_on_qty); ?> x <?php echo e(\App\CentralLogics\Helpers::set_symbol($addon['price'])); ?>

                                                        </span>
                                                    </div>
                                                    <?php ($add_ons_cost+=$addon['price']*$add_on_qty); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                            <div class="col col-md-2 align-self-center">
                                                <?php if($detail['discount_on_product']!=0): ?>
                                                    <h5>
                                                        <strike>

                                                        </strike>
                                                    </h5>
                                                <?php endif; ?>
                                                <h6><?php echo e(\App\CentralLogics\Helpers::set_symbol($detail['price']-$detail['discount_on_product'])); ?></h6>
                                            </div>
                                            <div class="col col-md-1 align-self-center">
                                                <h5><?php echo e($detail['quantity']); ?></h5>
                                            </div>

                                            <div class="col col-md-3 align-self-center text-right">
                                                <?php ($amount=($detail['price']-$detail['discount_on_product'])*$detail['quantity']); ?>
                                                <h5><?php echo e(\App\CentralLogics\Helpers::set_symbol($amount)); ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php ($sub_total+=$amount); ?>
                            <?php ($total_tax+=$detail['tax_amount']*$detail['quantity']); ?>
                            <!-- End Media -->
                                <hr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="row justify-content-md-end mb-3">
                            <div class="col-md-9 col-lg-8">
                                <dl class="row text-sm-right">
                                    <dt class="col-sm-6"><?php echo e(translate('items')); ?> <?php echo e(translate('price')); ?>:</dt>
                                    <dd class="col-sm-6"><?php echo e(\App\CentralLogics\Helpers::set_symbol($sub_total)); ?></dd>
                                    <dt class="col-sm-6"><?php echo e(translate('tax')); ?> / <?php echo e(translate('vat')); ?>:</dt>
                                    <dd class="col-sm-6"><?php echo e(\App\CentralLogics\Helpers::set_symbol($total_tax)); ?></dd>
                                    <dt class="col-sm-6"><?php echo e(translate('addon')); ?> <?php echo e(translate('cost')); ?>:</dt>
                                    <dd class="col-sm-6">
                                        <?php echo e(\App\CentralLogics\Helpers::set_symbol($add_ons_cost)); ?>

                                        <hr>
                                    </dd>

                                    <dt class="col-sm-6"><?php echo e(translate('subtotal')); ?>:</dt>
                                    <dd class="col-sm-6">
                                        <?php echo e(\App\CentralLogics\Helpers::set_symbol($sub_total+$total_tax+$add_ons_cost)); ?></dd>
                                    <dt class="col-sm-6"><?php echo e(translate('coupon')); ?> <?php echo e(translate('discount')); ?>:
                                    </dt>
                                    <dd class="col-sm-6">
                                        - <?php echo e(\App\CentralLogics\Helpers::set_symbol($order['coupon_discount_amount'])); ?></dd>
                                    <dt class="col-sm-6"><?php echo e(translate('delivery')); ?> <?php echo e(translate('fee')); ?>:</dt>
                                    <dd class="col-sm-6">
                                        <?php if($order['order_type']=='take_away'): ?>
                                            <?php ($del_c=0); ?>
                                        <?php else: ?>
                                            <?php ($del_c=$order['delivery_charge']); ?>
                                        <?php endif; ?>
                                        <?php echo e(\App\CentralLogics\Helpers::set_symbol($del_c)); ?>

                                        <hr>
                                    </dd>

                                    <dt class="col-sm-6"><?php echo e(translate('total')); ?>:</dt>
                                    <dd class="col-sm-6"><?php echo e(\App\CentralLogics\Helpers::set_symbol($sub_total+$del_c+$total_tax+$add_ons_cost-$order['coupon_discount_amount'])); ?></dd>
                                </dl>
                                <!-- End Row -->
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Body -->
                </div>
                <!-- End Card -->
            </div>

            <?php if($order->customer): ?>
                <div class="col-lg-4">
                    <!-- Card -->
                    <div class="card">
                        <!-- Header -->
                        <div class="card-header">
                            <h4 class="card-header-title"><?php echo e(translate('customer')); ?></h4>
                        </div>
                        <!-- End Header -->

                        <!-- Body -->
                            <div class="card-body">
                                <div class="media align-items-center" href="javascript:">
                                    <div class="avatar avatar-circle mr-3">
                                        <a href="<?php echo e(route('admin.customer.view',[$order->customer['id']])); ?>">
                                            <img
                                                class="avatar-img" style="width: 75px"
                                                onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                                src="<?php echo e(asset('storage/app/public/profile/'.$order->customer->image)); ?>"
                                                alt="Image Description">
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <span class="text-body text-hover-primary">
                                            <a href="<?php echo e(route('admin.customer.view',[$order->customer['id']])); ?>">
                                                <?php echo e($order->customer['f_name']." ".$order->customer['l_name']); ?>

                                            </a>
                                        </span>
                                    </div>
                                    <div class="media-body text-right">
                                        
                                    </div>
                                </div>

                                <hr>

                                <div class="media align-items-center" href="javascript:">
                                    <div class="icon icon-soft-info icon-circle mr-3">
                                        <i class="tio-shopping-basket-outlined"></i>
                                    </div>
                                    <div class="media-body">
                                        <span class="text-body text-hover-primary"><?php echo e(\App\Model\Order::where('user_id',$order['user_id'])->count()); ?> orders</span>
                                    </div>
                                    <div class="media-body text-right">
                                        
                                    </div>
                                </div>

                                <hr>

                                <div class="d-flex justify-content-between align-items-center">
                                    <h5><?php echo e(translate('contact')); ?> <?php echo e(translate('info')); ?></h5>
                                </div>

                                <ul class="list-unstyled list-unstyled-py-2">
                                    <li>
                                        <i class="tio-online mr-2"></i>
                                        <?php echo e($order->customer['email']); ?>

                                    </li>
                                    <li>
                                        <i class="tio-android-phone-vs mr-2"></i>
                                        <?php echo e($order->customer['phone']); ?>

                                    </li>
                                </ul>

                                <?php if($order['order_type']!='take_away'): ?>
                                    <hr>
                                    <?php ($address=\App\Model\CustomerAddress::find($order['delivery_address_id'])); ?>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h5><?php echo e(translate('delivery')); ?> <?php echo e(translate('address')); ?></h5>
                                        <?php if(isset($address)): ?>
                                            <a class="link" data-toggle="modal" data-target="#shipping-address-modal"
                                               href="javascript:"><?php echo e(translate('edit')); ?></a>
                                        <?php endif; ?>
                                    </div>
                                    <?php if(isset($address)): ?>
                                        <span class="d-block">
                                        <?php echo e($address['contact_person_name']); ?><br>
                                        <?php echo e($address['contact_person_number']); ?><br>
                                        <?php echo e($address['address_type']); ?><br>
                                        <a target="_blank"
                                           href="http://maps.google.com/maps?z=12&t=m&q=loc:<?php echo e($address['latitude']); ?>+<?php echo e($address['longitude']); ?>">
                                           <i class="tio-map"></i> <?php echo e($address['address']); ?><br>
                                        </a>
                                    </span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                    <!-- End Body -->
                    </div>
                    <!-- End Card -->
                </div>
            <?php endif; ?>
        </div>
        <!-- End Row -->
    </div>

    <!-- Modal -->
    <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title h4"
                        id="mySmallModalLabel"><?php echo e(translate('reference')); ?> <?php echo e(translate('code')); ?> <?php echo e(translate('add')); ?></h5>
                    <button type="button" class="btn btn-xs btn-icon btn-ghost-secondary" data-dismiss="modal"
                            aria-label="Close">
                        <i class="tio-clear tio-lg"></i>
                    </button>
                </div>

                <form action="<?php echo e(route('admin.orders.add-payment-ref-code',[$order['id']])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <!-- Input Group -->
                        <div class="form-group">
                            <input type="text" name="transaction_reference" class="form-control"
                                   placeholder="EX : Code123" required>
                        </div>
                        <!-- End Input Group -->
                        <button class="btn btn-primary"><?php echo e(translate('submit')); ?></button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <!-- End Modal -->

    <!-- Modal -->
    <div id="shipping-address-modal" class="modal fade" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalTopCoverTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <!-- Header -->
                <div class="modal-top-cover bg-dark text-center">
                    <figure class="position-absolute right-0 bottom-0 left-0" style="margin-bottom: -1px;">
                        <svg preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
                             viewBox="0 0 1920 100.1">
                            <path fill="#fff" d="M0,0c0,0,934.4,93.4,1920,0v100.1H0L0,0z"/>
                        </svg>
                    </figure>

                    <div class="modal-close">
                        <button type="button" class="btn btn-icon btn-sm btn-ghost-light" data-dismiss="modal"
                                aria-label="Close">
                            <svg width="16" height="16" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
                                <path fill="currentColor"
                                      d="M11.5,9.5l5-5c0.2-0.2,0.2-0.6-0.1-0.9l-1-1c-0.3-0.3-0.7-0.3-0.9-0.1l-5,5l-5-5C4.3,2.3,3.9,2.4,3.6,2.6l-1,1 C2.4,3.9,2.3,4.3,2.5,4.5l5,5l-5,5c-0.2,0.2-0.2,0.6,0.1,0.9l1,1c0.3,0.3,0.7,0.3,0.9,0.1l5-5l5,5c0.2,0.2,0.6,0.2,0.9-0.1l1-1 c0.3-0.3,0.3-0.7,0.1-0.9L11.5,9.5z"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <!-- End Header -->

                <div class="modal-top-cover-icon">
                    <span class="icon icon-lg icon-light icon-circle icon-centered shadow-soft">
                      <i class="tio-location-search"></i>
                    </span>
                </div>

                <?php ($address=\App\Model\CustomerAddress::find($order['delivery_address_id'])); ?>
                <?php if(isset($address)): ?>
                    <form action="<?php echo e(route('admin.orders.update-shipping',[$order['delivery_address_id']])); ?>"
                          method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="row mb-3">
                                <label for="requiredLabel" class="col-md-2 col-form-label input-label text-md-right">
                                    <?php echo e(translate('type')); ?>

                                </label>
                                <div class="col-md-10 js-form-message">
                                    <input type="text" class="form-control" name="address_type"
                                           value="<?php echo e($address['address_type']); ?>" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="requiredLabel" class="col-md-2 col-form-label input-label text-md-right">
                                    <?php echo e(translate('contact')); ?>

                                </label>
                                <div class="col-md-10 js-form-message">
                                    <input type="text" class="form-control" name="contact_person_number"
                                           value="<?php echo e($address['contact_person_number']); ?>" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="requiredLabel" class="col-md-2 col-form-label input-label text-md-right">
                                    <?php echo e(translate('name')); ?>

                                </label>
                                <div class="col-md-10 js-form-message">
                                    <input type="text" class="form-control" name="contact_person_name"
                                           value="<?php echo e($address['contact_person_name']); ?>" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="requiredLabel" class="col-md-2 col-form-label input-label text-md-right">
                                    <?php echo e(translate('address')); ?>

                                </label>
                                <div class="col-md-10 js-form-message">
                                    <input type="text" class="form-control" name="address"
                                           value="<?php echo e($address['address']); ?>"
                                           required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="requiredLabel" class="col-md-2 col-form-label input-label text-md-right">
                                    <?php echo e(translate('latitude')); ?>

                                </label>
                                <div class="col-md-4 js-form-message">
                                    <input type="text" class="form-control" name="latitude"
                                           value="<?php echo e($address['latitude']); ?>"
                                           required>
                                </div>
                                <label for="requiredLabel" class="col-md-2 col-form-label input-label text-md-right">
                                    <?php echo e(translate('longitude')); ?>

                                </label>
                                <div class="col-md-4 js-form-message">
                                    <input type="text" class="form-control" name="longitude"
                                           value="<?php echo e($address['longitude']); ?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-white"
                                    data-dismiss="modal"><?php echo e(translate('close')); ?></button>
                            <button type="submit"
                                    class="btn btn-primary"><?php echo e(translate('save')); ?> <?php echo e(translate('changes')); ?></button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- End Modal -->

    <!-- Modal -->
    <?php if($order['order_type'] != 'pos' && $order['order_type'] != 'take_away' && ($order['order_status'] != DELIVERED && $order['order_status'] != RETURNED && $order['order_status'] != CANCELED && $order['order_status'] != FAILED)): ?>
        <div class="modal fade" id="counter-change" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel" style="font-size: 20px"><?php echo e(translate('Need time to prepare the food')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="<?php echo e(route('admin.orders.increase-preparation-time', ['id' => $order->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="form-group text-center">
                                <input type="number" min="0" name="extra_minute" id="extra_minute" class="form-control" placeholder="<?php echo e(translate('EX : 20')); ?>" required>
                            </div>

                            <div class="form-group flex-between">
                                <div class="badge text-info shadow" onclick="predefined_time_input(10)" style="cursor: pointer"><?php echo e(translate('10min')); ?></div>
                                <div class="badge text-info shadow" onclick="predefined_time_input(20)" style="cursor: pointer"><?php echo e(translate('20min')); ?></div>
                                <div class="badge text-info shadow" onclick="predefined_time_input(30)" style="cursor: pointer"><?php echo e(translate('30min')); ?></div>
                                <div class="badge text-info shadow" onclick="predefined_time_input(40)" style="cursor: pointer"><?php echo e(translate('40min')); ?></div>
                                <div class="badge text-info shadow" onclick="predefined_time_input(50)" style="cursor: pointer"><?php echo e(translate('50min')); ?></div>
                                <div class="badge text-info shadow" onclick="predefined_time_input(60)" style="cursor: pointer"><?php echo e(translate('60min')); ?></div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(translate('Close')); ?></button>
                            <button type="submit" class="btn btn-primary"><?php echo e(translate('Submit')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <!-- End Modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function addDeliveryMan(id) {
            $.ajax({
                type: "GET",
                url: '<?php echo e(url('/')); ?>/admin/orders/add-delivery-man/<?php echo e($order['id']); ?>/' + id,
                data: $('#product_form').serialize(),
                success: function (data) {
                    if(data.status == true) {
                        toastr.success('<?php echo e(\App\CentralLogics\translate("Delivery man successfully assigned/changed")); ?>', {
                            CloseButton: true,
                            ProgressBar: true
                        });
                    }else{
                        toastr.error('<?php echo e(\App\CentralLogics\translate("Deliveryman man can not assign/change in that status")); ?>', {
                            CloseButton: true,
                            ProgressBar: true
                        });
                    }
                },
                error: function () {
                    toastr.error('<?php echo e(\App\CentralLogics\translate("Add valid data")); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });
        }

        function last_location_view() {
            toastr.warning('<?php echo e(\App\CentralLogics\translate("Only available when order is out for delivery!")); ?>', {
                CloseButton: true,
                ProgressBar: true
            });
        }
    </script>

    <script>
        function predefined_time_input(min) {
            document.getElementById("extra_minute").value = min;
        }
    </script>
    <?php if($order['order_type'] != 'pos' && $order['order_type'] != 'take_away' && ($order['order_status'] != DELIVERED && $order['order_status'] != RETURNED && $order['order_status'] != CANCELED && $order['order_status'] != FAILED)): ?>
        <script>
            const expire_time = "<?php echo e($order['remaining_time']); ?>";
            var countDownDate = new Date(expire_time).getTime();
            const time_zone = "<?php echo e(\App\CentralLogics\Helpers::get_business_settings('time_zone') ?? 'UTC'); ?>";

            var x = setInterval(function() {
                var now = new Date(new Date().toLocaleString("en-US", {timeZone: time_zone})).getTime();

                var distance = countDownDate - now;

                var days = Math.trunc(distance / (1000 * 60 * 60 * 24));
                var hours = Math.trunc((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.trunc((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.trunc((distance % (1000 * 60)) / 1000);


                document.getElementById("timer-icon").classList.remove("d-none");
                document.getElementById("edit-icon").classList.remove("d-none");
                $text = (distance < 0) ? "<?php echo e(translate('over')); ?>" : "<?php echo e(translate('left')); ?>";
                document.getElementById("counter").innerHTML = Math.abs(days) + "d " + Math.abs(hours) + "h " + Math.abs(minutes) + "m " + Math.abs(seconds) + "s " + $text;
                if (distance < 0) {
                    var element = document.getElementById('counter');
                    element.classList.add('text-danger');
                }
            }, 1000);
        </script>
    <?php endif; ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/order/order-view.blade.php ENDPATH**/ ?>