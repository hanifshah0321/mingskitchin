<?php $__env->startSection('title', translate('Settings')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(translate('Firebase Message Configuration')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <?php ($data=\App\CentralLogics\Helpers::get_business_settings('firebase_message_config')); ?>
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.web-app.system-setup.firebase_message_config'):'javascript:'); ?>" method="post"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($data)): ?>
                        <div class="form-group mb-2">
                            <label style="padding-left: 10px"><?php echo e(translate('API Key')); ?></label><br>
                            <input type="text" placeholder="" class="form-control" name="apiKey"
                                   value="<?php echo e(env('APP_MODE')!='demo'?$data['apiKey']:''); ?>" required autocomplete="off">
                        </div>

                        <div class="form-group mb-2">
                            <label style="padding-left: 10px"><?php echo e(translate('Auth Domain')); ?></label><br>
                            <input type="text" class="form-control" name="authDomain" value="<?php echo e(env('APP_MODE')!='demo'?$data['authDomain']:''); ?>" required autocomplete="off">
                        </div>
                        <div class="form-group mb-2">
                            <label style="padding-left: 10px"><?php echo e(translate('Project ID')); ?></label><br>
                            <input type="text" class="form-control" name="projectId" value="<?php echo e(env('APP_MODE')!='demo'?$data['projectId']:''); ?>" required autocomplete="off">
                        </div>
                        <div class="form-group mb-2">
                            <label style="padding-left: 10px"><?php echo e(translate('Storage Bucket')); ?></label><br>
                            <input type="text" class="form-control" name="storageBucket" value="<?php echo e(env('APP_MODE')!='demo'?$data['storageBucket']:''); ?>" required autocomplete="off">
                        </div>

                        <div class="form-group mb-2">
                            <label style="padding-left: 10px"><?php echo e(translate('Messaging Sender ID')); ?></label><br>
                            <input type="text" placeholder="" class="form-control" name="messagingSenderId"
                                   value="<?php echo e(env('APP_MODE')!='demo'?$data['messagingSenderId']:''); ?>" required autocomplete="off">
                        </div>

                        <div class="form-group mb-2">
                            <label style="padding-left: 10px"><?php echo e(translate('App ID')); ?></label><br>
                            <input type="text" placeholder="" class="form-control" name="appId"
                                   value="<?php echo e(env('APP_MODE')!='demo'?$data['appId']:''); ?>" required autocomplete="off">
                        </div>

                        <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>" onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>" class="btn btn-primary mb-2"><?php echo e(translate('save')); ?></button>
                    <?php else: ?>
                        <button type="submit" class="btn btn-primary mb-2"><?php echo e(translate('configure')); ?></button>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/business-settings/firebase-config-index.blade.php ENDPATH**/ ?>