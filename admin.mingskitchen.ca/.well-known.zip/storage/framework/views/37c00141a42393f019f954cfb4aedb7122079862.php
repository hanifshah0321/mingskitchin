<div id="sidebarMain" class="d-none">
    <aside
        class="js-navbar-vertical-aside navbar navbar-vertical-aside navbar-vertical navbar-vertical-fixed navbar-expand-xl navbar-bordered  ">
        <div class="navbar-vertical-container text-capitalize">
            <div class="navbar-vertical-footer-offset">
                <div class="navbar-brand-wrapper justify-content-between">
                    <!-- Logo -->

                    <?php ($restaurant_logo=\App\Model\BusinessSetting::where(['key'=>'logo'])->first()->value); ?>
                    <a class="navbar-brand" href="<?php echo e(route('admin.dashboard')); ?>" aria-label="Front">
                        <img class="navbar-brand-logo"
                             onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'"
                             src="<?php echo e(asset('storage/app/public/restaurant/'.$restaurant_logo)); ?>"
                             alt="Logo">
                        <img class="navbar-brand-logo-mini"
                             onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'"
                             src="<?php echo e(asset('storage/app/public/restaurant/'.$restaurant_logo)); ?>" alt="Logo">
                    </a>

                    <!-- End Logo -->

                    <!-- Navbar Vertical Toggle -->
                    <button type="button"
                            class="js-navbar-vertical-aside-toggle-invoker navbar-vertical-aside-toggle btn btn-icon btn-xs btn-ghost-dark">
                        <i class="tio-clear tio-lg"></i>
                    </button>
                    <!-- End Navbar Vertical Toggle -->
                </div>

                <!-- Content -->
                <div class="navbar-vertical-content">
                    <ul class="navbar-nav navbar-nav-lg nav-tabs">

                        <!-- Dashboards -->
                        <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin')?'show':''); ?>">
                            <a class="js-navbar-vertical-aside-menu-link nav-link"
                               href="<?php echo e(route('admin.dashboard')); ?>" title="Dashboards">
                                <i class="tio-home-vs-1-outlined nav-icon"></i>
                                <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('dashboard')); ?>

                                    </span>
                            </a>
                        </li>
                        <!-- End Dashboards -->

                        <?php if(Helpers::module_permission_check(MANAGEMENT_SECTION['pos_management'])): ?>
                            <li class="nav-item">
                                <small
                                    class="nav-subtitle"><?php echo e(translate('pos')); ?> <?php echo e(translate('system')); ?></small>
                                <small class="tio-more-horizontal nav-subtitle-replacer"></small>
                            </li>

                            <!-- POS -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/pos/*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:">
                                    <i class="tio-shopping nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('POS')); ?></span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub"
                                    style="display: <?php echo e(Request::is('admin/pos/*')?'block':'none'); ?>">
                                    <li class="nav-item <?php echo e(Request::is('admin/pos/')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.pos.index')); ?>"
                                           title="<?php echo e(translate('pos')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span
                                                class="text-truncate"><?php echo e(translate('pos')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/pos/orders')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.pos.orders')); ?>" title="<?php echo e(translate('orders')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('orders')); ?>

                                            <span class="badge badge-info badge-pill ml-1">
                                                <?php echo e(\App\Model\Order::Pos()->count()); ?>

                                            </span>
                                        </span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- End POS -->
                        <?php endif; ?>

                        <?php if(Helpers::module_permission_check(MANAGEMENT_SECTION['order_management'])): ?>
                            <li class="nav-item">
                                <small
                                    class="nav-subtitle"><?php echo e(translate('order')); ?> <?php echo e(translate('section')); ?></small>
                                <small class="tio-more-horizontal nav-subtitle-replacer"></small>
                            </li>

                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/orders*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:">
                                    <i class="tio-shopping-cart nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('order')); ?>

                                    </span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub"
                                    style="display: <?php echo e(Request::is('admin/order*')?'block':'none'); ?>">
                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/all')?'active':''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('admin.orders.list',['all'])); ?>" title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('all')); ?>

                                                <span class="badge badge-info badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/pending')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.orders.list',['pending'])); ?>" title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('pending')); ?>

                                                <span class="badge badge-soft-info badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->where(['order_status'=>'pending'])->notSchedule()->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/confirmed')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.orders.list',['confirmed'])); ?>" title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('confirmed')); ?>

                                                    <span class="badge badge-soft-success badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->where(['order_status'=>'confirmed'])->notSchedule()->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/processing')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.orders.list',['processing'])); ?>" title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('processing')); ?>

                                                    <span class="badge badge-warning badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->where(['order_status'=>'processing'])->notSchedule()->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/out_for_delivery')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.orders.list',['out_for_delivery'])); ?>"
                                           title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('out_for_delivery')); ?>

                                                    <span class="badge badge-warning badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->where(['order_status'=>'out_for_delivery'])->notSchedule()->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/delivered')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.orders.list',['delivered'])); ?>" title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('delivered')); ?>

                                                    <span class="badge badge-success badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->where(['order_status'=>'delivered'])->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/returned')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.orders.list',['returned'])); ?>" title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('returned')); ?>

                                                    <span class="badge badge-soft-danger badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->where(['order_status'=>'returned'])->notSchedule()->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/failed')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.orders.list',['failed'])); ?>" title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('failed')); ?>

                                                <span class="badge badge-danger badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->where(['order_status'=>'failed'])->notSchedule()->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>

                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/canceled')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.orders.list',['canceled'])); ?>" title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('canceled')); ?>

                                                    <span class="badge badge-soft-dark badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->where(['order_status'=>'canceled'])->notSchedule()->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>

                                    <li class="nav-item <?php echo e(Request::is('admin/orders/list/schedule')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.orders.list',['schedule'])); ?>" title="">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate">
                                                <?php echo e(translate('scheduled')); ?>

                                                    <span class="badge badge-soft-info badge-pill ml-1">
                                                    <?php echo e(\App\Model\Order::notPos()->where('delivery_date','>',\Carbon\Carbon::now()->format('Y-m-d'))->count()); ?>

                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- End Pages -->
                        <?php endif; ?>

                        <?php if(Helpers::module_permission_check(MANAGEMENT_SECTION['product_management'])): ?>
                            <li class="nav-item">
                                <small
                                    class="nav-subtitle"><?php echo e(translate('product')); ?> <?php echo e(translate('section')); ?></small>
                                <small class="tio-more-horizontal nav-subtitle-replacer"></small>
                            </li>


                            <!-- Pages -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/category*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:"
                                >
                                    <i class="tio-category nav-icon"></i>
                                    <span
                                        class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('category')); ?></span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub"
                                    style="display: <?php echo e(Request::is('admin/category*')?'block':'none'); ?>">
                                    <li class="nav-item <?php echo e(Request::is('admin/category/add')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.category.add')); ?>"
                                           title="add new category">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('category')); ?></span>
                                        </a>
                                    </li>

                                    <li class="nav-item <?php echo e(Request::is('admin/category/add-sub-category')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.category.add-sub-category')); ?>"
                                           title="add new sub category">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('sub_category')); ?></span>
                                        </a>
                                    </li>

                                    
                                </ul>
                            </li>
                            <!-- End Pages -->


                            <!-- Pages -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/attribute*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link"
                                   href="<?php echo e(route('admin.attribute.add-new')); ?>"
                                >
                                    <i class="tio-apps nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('attribute')); ?>

                                    </span>
                                </a>
                            </li>
                            <!-- End Pages -->

                            <!-- Pages -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/addon*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link"
                                   href="<?php echo e(route('admin.addon.add-new')); ?>"
                                >
                                    <i class="tio-add-circle-outlined nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('addon')); ?>

                                    </span>
                                </a>
                            </li>
                            <!-- End Pages -->

                            <!-- Pages -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/product*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:"
                                >
                                    <i class="tio-premium-outlined nav-icon"></i>
                                    <span
                                        class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('product')); ?></span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub"
                                    style="display: <?php echo e(Request::is('admin/product*')?'block':'none'); ?>">
                                    <li class="nav-item <?php echo e(Request::is('admin/product/add-new')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.product.add-new')); ?>"
                                           title="add new product">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span
                                                class="text-truncate"><?php echo e(translate('add')); ?> <?php echo e(translate('new')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/product/list')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.product.list')); ?>" title="product list">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('list')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/product/bulk-import')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.product.bulk-import')); ?>" title="bulk import">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('bulk_import')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/product/bulk-export')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.product.bulk-export')); ?>" title="bulk export">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('bulk_export')); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- End Pages -->

                            <!-- Pages -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/banner*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:"
                                >
                                    <i class="tio-image nav-icon"></i>
                                    <span
                                        class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('banner')); ?></span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub"
                                    style="display: <?php echo e(Request::is('admin/banner*')?'block':'none'); ?>">
                                    <li class="nav-item <?php echo e(Request::is('admin/banner/add-new')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.banner.add-new')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span
                                                class="text-truncate"><?php echo e(translate('add')); ?> <?php echo e(translate('new')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/banner/list')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.banner.list')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('list')); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- End Pages -->
                        <?php endif; ?>

                        <?php if(Helpers::module_permission_check(MANAGEMENT_SECTION['business_management'])): ?>
                            <li class="nav-item">
                                <small class="nav-subtitle"
                                       title="Layouts"><?php echo e(translate('business')); ?> <?php echo e(translate('section')); ?></small>
                                <small class="tio-more-horizontal nav-subtitle-replacer"></small>
                            </li>



                              <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/employee*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle"
                                   href="javascript:">
                                    <i class="tio-user nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                            Membership
                                        </span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub"
                                    style="display: <?php echo e(Request::is('admin/employee*')?'block':'none'); ?>">
                                    <li class="nav-item <?php echo e(Request::is('admin/employee/add-new')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.membership.add-new')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('add_new')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/employee/list')?'active':''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('admin.membership.list')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('List')); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </li>


                            

                            <!-- BRANCH -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/branch*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link" href="<?php echo e(route('admin.branch.add-new')); ?>">
                                    <i class="tio-shop nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('branch')); ?>

                                    </span>
                                </a>
                            </li>

                            <!-- MESSAGE -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/message*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link" href="<?php echo e(route('admin.message.list')); ?>">
                                    <i class="tio-messages nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('messages')); ?>

                                    </span>
                                </a>
                            </li>

                            <!-- REVIEWS -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/reviews*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link" href="<?php echo e(route('admin.reviews.list')); ?>">
                                    <i class="tio-star nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('product')); ?> <?php echo e(translate('reviews')); ?>

                                    </span>
                                </a>
                            </li>


                            <!-- NOTIFICATION -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/notification*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link" href="<?php echo e(route('admin.notification.add-new')); ?>">
                                    <i class="tio-notifications nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('send')); ?> <?php echo e(translate('notification')); ?>

                                    </span>
                                </a>
                            </li>

                            <!-- COUPON -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/coupon*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link" href="<?php echo e(route('admin.coupon.add-new')); ?>">
                                    <i class="tio-gift nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('coupon')); ?></span>
                                </a>
                            </li>

                            <!-- Restaurant Settings -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/restaurant/')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:">
                                    <i class="tio-settings nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('Restaurant Settings')); ?></span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub" style="display: <?php echo e(Request::is('admin/business-settings/restaurant/*')?'block':'none'); ?>">
                                    <!-- restaurant-setup -->
                                    <li class="nav-item <?php echo e(Request::is('admin/business-settings/restaurant/restaurant-setup')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.business-settings.restaurant.restaurant-setup')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('restaurant')); ?> <?php echo e(translate('setup')); ?></span>
                                        </a>
                                    </li>
                                    <!-- time-schedule -->
                                    <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/restaurant/time-schedule')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.business-settings.restaurant.time_schedule_index')); ?>"
                                           title="<?php echo e(translate('Restaurant Time Schedule')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('Restaurant Time Schedule')); ?></span>
                                        </a>
                                    </li>
                                    <!-- location-setup -->
                                    <li class="nav-item <?php echo e(Request::is('admin/business-settings/restaurant/location-setup')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.business-settings.restaurant.location-setup')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('location')); ?> <?php echo e(translate('setup')); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </li>

                            <!-- WEB & APPS SETTINGS -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/web-app/*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:">
                                    <i class="tio-website nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('Web & Apps Settings')); ?></span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub" style="display: <?php echo e(Request::is('admin/business-settings/web-app*')?'block':'none'); ?>">
                                    <!-- MAIL CONFIG -->
                                    <li class="nav-item <?php echo e(Request::is('admin/business-settings/web-app/mail-config')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.business-settings.web-app.mail-config')); ?>">
                                            <span class="tio-gmail-outlined nav-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('mail')); ?> <?php echo e(translate('config')); ?></span>
                                        </a>
                                    </li>
                                    <!-- SMS-MODULE -->
                                    <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/web-app/sms-module')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.business-settings.web-app.sms-module')); ?>"
                                           title="<?php echo e(translate('sms')); ?> <?php echo e(translate('module')); ?>">
                                            <span class="tio-sms nav-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('sms')); ?> <?php echo e(translate('module')); ?></span>
                                        </a>
                                    </li>
                                    <!-- PAYMENT-MODULE -->
                                    <li class="nav-item <?php echo e(Request::is('admin/business-settings/web-app/payment-method')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.business-settings.web-app.payment-method')); ?>">
                                            <span class="tio-money nav-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('payment')); ?> <?php echo e(translate('methods')); ?></span>
                                        </a>
                                    </li>
                                    <!-- SYSTEM SETTINGS -->
                                    <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/web-app/system-setup*')?'active':''); ?>">
                                        <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:">
                                            <i class="tio-security-on-outlined nav-icon"></i>
                                            <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('System Settings')); ?></span>
                                        </a>
                                        <ul class="js-navbar-vertical-aside-submenu nav nav-sub" style="display: <?php echo e(Request::is('admin/business-settings/web-app/system-setup*')?'block':'none'); ?>">
                                            <!-- app-setting -->
                                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/web-app/system-setup/app-setting')?'active':''); ?>">
                                                <a class="nav-link " href="<?php echo e(route('admin.business-settings.web-app.system-setup.app_setting')); ?>"
                                                   title="<?php echo e(translate('App Setting')); ?>">
                                                    <span class="tio-circle nav-indicator-icon"></span>
                                                    <span class="text-truncate"><?php echo e(translate('App Setting')); ?></span>
                                                </a>
                                            </li>
                                            <!-- clean-db -->
                                            <li class="nav-item <?php echo e(Request::is('admin/business-settings/web-app/system-setup/db*')?'active':''); ?>">
                                                <a class="nav-link " href="<?php echo e(route('admin.business-settings.web-app.system-setup.db-index')); ?>"
                                                >
                                                    <span class="tio-circle nav-indicator-icon"></span>
                                                    <span
                                                        class="text-truncate"><?php echo e(translate('clean')); ?> <?php echo e(translate('database')); ?></span>
                                                </a>
                                            </li>
                                            <!-- firebase-message-config -->
                                            <li class="nav-item <?php echo e(Request::is('admin/business-settings/web-app/system-setup/firebase-message-config')?'active':''); ?>">
                                                <a class="nav-link " href="<?php echo e(route('admin.business-settings.web-app.system-setup.firebase_message_config_index')); ?>"
                                                >
                                                    <span class="tio-circle nav-indicator-icon"></span>
                                                    <span
                                                        class="text-truncate"><?php echo e(translate('Firebase Message Config')); ?></span>
                                                </a>
                                            </li>
                                            <!-- language -->
                                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/web-app/system-setup/language*')?'active':''); ?>">
                                                <a class="nav-link " href="<?php echo e(route('admin.business-settings.web-app.system-setup.language.index')); ?>"
                                                   title="<?php echo e(translate('languages')); ?>">
                                                    <span class="tio-circle nav-indicator-icon"></span>
                                                    <span class="text-truncate"><?php echo e(translate('languages')); ?></span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <!-- 3RD PARTY SETTINGS -->
                                    <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/web-app/third-party*')?'active':''); ?>">
                                        <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:">
                                            <i class="tio-settings-vs nav-icon"></i>
                                            <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('3rd Party Settings')); ?></span>
                                        </a>
                                        <ul class="js-navbar-vertical-aside-submenu nav nav-sub" style="display: <?php echo e(Request::is('admin/business-settings/web-app/third-party*')?'block':'none'); ?>">
                                            <!-- map-api-settings -->
                                            <li class="nav-item <?php echo e(Request::is('admin/business-settings/web-app/third-party/map-api-settings')?'active':''); ?>">
                                                <a class="nav-link "
                                                   href="<?php echo e(route('admin.business-settings.web-app.third-party.map_api_settings')); ?>">
                                                    <span class="tio-circle nav-indicator-icon"></span>
                                                    <span class="text-truncate"><?php echo e(translate('map_api_setting')); ?></span>
                                                </a>
                                            </li>
                                            <!-- social-media -->
                                            <li class="nav-item <?php echo e(Request::is('admin/business-settings/web-app/third-party/social-media')?'active':''); ?>">
                                                <a class="nav-link "
                                                   href="<?php echo e(route('admin.business-settings.web-app.third-party.social-media')); ?>">
                                                    <span class="tio-circle nav-indicator-icon"></span>
                                                    <span class="text-truncate"><?php echo e(translate('Social Media')); ?></span>
                                                </a>
                                            </li>
                                            <!-- recaptcha -->
                                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/web-app/third-party/recaptcha*')?'active':''); ?>">
                                                <a class="nav-link " href="<?php echo e(route('admin.business-settings.web-app.third-party.recaptcha_index')); ?>"
                                                   title="<?php echo e(translate('languages')); ?>">
                                                    <span class="tio-circle nav-indicator-icon"></span>
                                                    <span class="text-truncate"><?php echo e(translate('reCaptcha')); ?></span>
                                                </a>
                                            </li>
                                            <!-- fcm-index -->
                                            <li class="nav-item <?php echo e(Request::is('admin/business-settings/web-app/third-party/fcm-index')?'active':''); ?>">
                                                <a class="nav-link " href="<?php echo e(route('admin.business-settings.web-app.third-party.fcm-index')); ?>"
                                                   title="">
                                                    <span class="tio-circle nav-indicator-icon"></span>
                                                    <span
                                                        class="text-truncate"><?php echo e(translate('push')); ?> <?php echo e(translate('notification')); ?></span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                </ul>
                            </li>

                            <!-- PAGE SETUP -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/business-settings/page-setup/*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:">
                                    <i class="tio-pages nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('Page Setup')); ?></span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub" style="display: <?php echo e(Request::is('admin/business-settings/page-setup*')?'block':'none'); ?>">
                                    <!-- about-us -->
                                    <li class="nav-item <?php echo e(Request::is('admin/business-settings/page-setup/about-us')?'active':''); ?>">
                                        <a class="nav-link "
                                           href="<?php echo e(route('admin.business-settings.page-setup.about-us')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('about_us')); ?></span>
                                        </a>
                                    </li>
                                    <!-- terms-and-conditions -->
                                    <li class="nav-item <?php echo e(Request::is('admin/business-settings/page-setup/terms-and-conditions')?'active':''); ?>">
                                        <a class="nav-link "
                                           href="<?php echo e(route('admin.business-settings.page-setup.terms-and-conditions')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('terms_and_condition')); ?></span>
                                        </a>
                                    </li>
                                    <!-- privacy-policy -->
                                    <li class="nav-item <?php echo e(Request::is('admin/business-settings/page-setup/privacy-policy')?'active':''); ?>">
                                        <a class="nav-link "
                                           href="<?php echo e(route('admin.business-settings.page-setup.privacy-policy')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('privacy_policy')); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>

                        <?php if(Helpers::module_permission_check(MANAGEMENT_SECTION['employee_management'])): ?>
                            <li class="nav-item <?php echo e((Request::is('admin/employee*') || Request::is('admin/custom-role*'))?'scroll-here':''); ?>">
                                <small class="nav-subtitle"><?php echo e(translate('employee_section')); ?></small>
                                <small class="tio-more-horizontal nav-subtitle-replacer"></small>
                            </li>

                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/custom-role*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link"
                                   href="<?php echo e(route('admin.custom-role.create')); ?>">
                                    <i class="tio-incognito nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                            <?php echo e(translate('employee_role')); ?></span>
                                </a>
                            </li>
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/employee*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle"
                                   href="javascript:">
                                    <i class="tio-user nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                            <?php echo e(translate('employees')); ?>

                                        </span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub"
                                    style="display: <?php echo e(Request::is('admin/employee*')?'block':'none'); ?>">
                                    <li class="nav-item <?php echo e(Request::is('admin/employee/add-new')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.employee.add-new')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('add_new')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/employee/list')?'active':''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('admin.employee.list')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('List')); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>

                        <?php if(Helpers::module_permission_check(MANAGEMENT_SECTION['deliveryman_management'])): ?>
                            <li class="nav-item">
                                <small class="nav-subtitle"
                                       title="Layouts"><?php echo e(translate('deliveryman')); ?> <?php echo e(translate('section')); ?></small>
                                <small class="tio-more-horizontal nav-subtitle-replacer"></small>
                            </li>

                            <!-- Pages -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/delivery-man/add')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link"
                                   href="<?php echo e(route('admin.delivery-man.add')); ?>"
                                >
                                    <i class="tio-running nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('register')); ?>

                                    </span>
                                </a>
                            </li>
                            <!-- End Pages -->

                            <!-- Pages -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/delivery-man/list')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link"
                                   href="<?php echo e(route('admin.delivery-man.list')); ?>">
                                    <i class="tio-filter-list nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('list')); ?>

                                    </span>
                                </a>
                            </li>

                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/delivery-man/reviews/list')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link"
                                   href="<?php echo e(route('admin.delivery-man.reviews.list')); ?>">
                                    <i class="tio-star-outlined nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('reviews')); ?>

                                    </span>
                                </a>
                            </li>
                            <!-- End Pages -->
                        <?php endif; ?>

                        <?php if(Helpers::module_permission_check(MANAGEMENT_SECTION['customer_management'])): ?>
                            <li class="nav-item">
                                <small class="nav-subtitle"
                                       title="Documentation"><?php echo e(translate('customer')); ?> <?php echo e(translate('section')); ?></small>
                                <small class="tio-more-horizontal nav-subtitle-replacer"></small>
                            </li>

                            <!-- Pages -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/customer/list*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link"
                                   href="<?php echo e(route('admin.customer.list')); ?>">
                                    <i class="tio-poi-user nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('customer')); ?> <?php echo e(translate('list')); ?>

                                    </span>
                                </a>
                            </li>
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/customer/transaction*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link"
                                   href="<?php echo e(route('admin.customer.transaction')); ?>"
                                >
                                    <i class="tio-format-points nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('point')); ?> <?php echo e(translate('history')); ?>

                                    </span>
                                </a>
                            </li>
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/customer/subscribed-email*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link"
                                   href="<?php echo e(route('admin.customer.subscribed_emails')); ?>">
                                    <i class="tio-email-outlined nav-icon"></i>
                                    <span class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate">
                                        <?php echo e(translate('Subscribed Emails')); ?>

                                    </span>
                                </a>
                            </li>
                            <!-- End Pages -->
                        <?php endif; ?>

                        <?php if(Helpers::module_permission_check(MANAGEMENT_SECTION['report_management'])): ?>
                            <li class="nav-item">
                                <div class="nav-divider"></div>
                            </li>

                            <li class="nav-item">
                                <small class="nav-subtitle"
                                       title="Documentation"><?php echo e(translate('report_and_analytics')); ?></small>
                                <small class="tio-more-horizontal nav-subtitle-replacer"></small>
                            </li>

                            <!-- Pages -->
                            <li class="navbar-vertical-aside-has-menu <?php echo e(Request::is('admin/report*')?'active':''); ?>">
                                <a class="js-navbar-vertical-aside-menu-link nav-link nav-link-toggle" href="javascript:"
                                >
                                    <i class="tio-report-outlined nav-icon"></i>
                                    <span
                                        class="navbar-vertical-aside-mini-mode-hidden-elements text-truncate"><?php echo e(translate('reports')); ?></span>
                                </a>
                                <ul class="js-navbar-vertical-aside-submenu nav nav-sub"
                                    style="display: <?php echo e(Request::is('admin/report*')?'block':'none'); ?>">
                                    <li class="nav-item <?php echo e(Request::is('admin/report/earning')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.report.earning')); ?>"
                                        >
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span
                                                class="text-truncate"><?php echo e(translate('earning')); ?> <?php echo e(translate('report')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/report/order')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.report.order')); ?>"
                                        >
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span
                                                class="text-truncate"><?php echo e(translate('order')); ?> <?php echo e(translate('report')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/report/deliveryman-report')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.report.deliveryman_report')); ?>"
                                        >
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span
                                                class="text-truncate"><?php echo e(translate('DeliveryMan Report')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/report/product-report')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.report.product-report')); ?>"
                                        >
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span
                                                class="text-truncate"><?php echo e(translate('product')); ?> <?php echo e(translate('report')); ?></span>
                                        </a>
                                    </li>
                                    <li class="nav-item <?php echo e(Request::is('admin/report/sale-report')?'active':''); ?>">
                                        <a class="nav-link " href="<?php echo e(route('admin.report.sale-report')); ?>">
                                            <span class="tio-circle nav-indicator-icon"></span>
                                            <span class="text-truncate"><?php echo e(translate('sale')); ?> <?php echo e(translate('report')); ?></span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!-- End Pages -->
                        <?php endif; ?>

                        <li class="nav-item" style="padding-top: 100px">
                            <div class=""></div>
                        </li>
                    </ul>
                </div>
                <!-- End Content -->
            </div>
        </div>
    </aside>
</div>

<div id="sidebarCompact" class="d-none">

</div>



<?php /**PATH C:\xampp\htdocs\Ming's\resources\views/layouts/admin/partials/_sidebar.blade.php ENDPATH**/ ?>