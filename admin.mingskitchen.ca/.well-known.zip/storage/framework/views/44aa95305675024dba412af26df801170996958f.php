<?php $__env->startSection('title', translate('Settings')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
    <?php ($branch_count=\App\Model\Branch::count()); ?>
    <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(translate('location coverage setup')); ?></h1>
                    <div class="card-footer">
                        <div class="row">
                            <div class="col-12" style="overflow-x: scroll;">
                                <span class="badge badge-soft-danger" style="text-align: left">
                                    <?php echo e(translate('This location setup is for your Main branch. Carefully set your restaurant location and coverage area. If you want to ignore the coverage area then keep the input box empty.')); ?>

                                    <br>
                                    <?php echo e(translate('You can ignore this when you have only the default branch and you do not want coverage area.')); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.restaurant.update-location'):'javascript:'); ?>" method="post"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php ($data=\App\Model\Branch::find(1)); ?>
                    <div class="row">
                        
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('latitude')); ?></label>
                                <input type="text" value="<?php echo e($data['latitude']); ?>"
                                       name="latitude" class="form-control"
                                       placeholder="<?php echo e(translate('Ex : -94.22213')); ?>" <?php echo e($branch_count>1?'required':''); ?>>
                            </div>
                        </div>

                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('longitude')); ?></label>
                                <input type="text" value="<?php echo e($data['longitude']); ?>"
                                       name="longitude" class="form-control"
                                       placeholder="<?php echo e(translate('Ex : 103.344322')); ?>" <?php echo e($branch_count>1?'required':''); ?>>
                            </div>
                        </div>

                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label" for="">
                                    <i class="tio-info-outined"
                                       data-toggle="tooltip"
                                       data-placement="top"
                                       title="<?php echo e(translate('This value is the radius from your restaurant location, and customer can order food inside  the circle calculated by this radius.')); ?>"></i>
                                    <?php echo e(translate('coverage')); ?> ( <?php echo e(translate('km')); ?> )
                                </label>
                                <input type="number" value="<?php echo e($data['coverage']); ?>"
                                       name="coverage" class="form-control" placeholder="<?php echo e(translate('Ex : 3')); ?>" <?php echo e($branch_count>1?'required':''); ?>>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>" onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>" class="btn btn-primary"><?php echo e(translate('update')); ?></button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/business-settings/location-index.blade.php ENDPATH**/ ?>