<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="">
        <td class="">
            <?php echo e($customers->firstitem()+$key); ?>

        </td>
        <td class="table-column-pl-0">
            <a href="<?php echo e(route('admin.customer.view',[$customer['id']])); ?>">
                <?php echo e($customer['f_name']." ".$customer['l_name']); ?>

            </a>
        </td>
        <td>
            <?php echo e($customer['email']); ?>

        </td>
        <td>
            <?php echo e($customer['phone']); ?>

        </td>
        <td>
            <label class="badge badge-soft-info">
                <?php echo e($customer->orders->count()); ?>

            </label>
        </td>
        <td class="show-point-<?php echo e($customer['id']); ?>-table">
            <?php echo e($customer['point']); ?>

        </td>
        <td>
            <div class="dropdown">
                <button class="btn btn-outline-secondary dropdown-toggle" type="button"
                        id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                    <i class="tio-settings"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item"
                       href="<?php echo e(route('admin.customer.view',[$customer['id']])); ?>">
                        <i class="tio-visible"></i> <?php echo e(translate('view')); ?>

                    </a>
                    <a class="dropdown-item" href="javascript:" onclick="set_point_modal_data('<?php echo e(route('admin.customer.set-point-modal-data',[$customer['id']])); ?>')">
                        <i class="tio-coin"></i> <?php echo e(translate('Add Point')); ?>

                    </a>
                    
                </div>
            </div>
        </td>
    </tr>
<!--    <div class="modal fade" id="exampleModal-<?php echo e($customer['id']); ?>" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Internal Point</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="javascript:" method="POST" id="point-form-<?php echo e($customer['id']); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <h5>
                            <label class="badge badge-soft-info">
                                <?php echo e($customer['f_name']); ?> <?php echo e($customer['l_name']); ?>

                            </label>
                            <label class="show-point-<?php echo e($customer['id']); ?>">
                                ( Available Point : <?php echo e($customer['point']); ?> )
                            </label>
                        </h5>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Add Point :</label>
                            <input type="number" min="1" value="1" max="1000000"
                                   class="form-control"
                                   name="point">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            Close
                        </button>
                        <button type="button"
                                onclick="add_point('point-form-<?php echo e($customer['id']); ?>','<?php echo e(route('admin.customer.add-point',[$customer['id']])); ?>','<?php echo e($customer['id']); ?>')"
                                class="btn btn-primary">Add
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/customer/partials/_table.blade.php ENDPATH**/ ?>