<?php $__env->startSection('title', translate('Add new delivery-man')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i class="tio-add-circle-outlined"></i> <?php echo e(translate('add')); ?> <?php echo e(translate('new')); ?> <?php echo e(translate('deliveryman')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(route('admin.delivery-man.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('first')); ?> <?php echo e(translate('name')); ?></label>
                                <input type="text" name="f_name" class="form-control" placeholder="<?php echo e(translate('first')); ?> <?php echo e(translate('name')); ?>"
                                       required>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('last')); ?> <?php echo e(translate('name')); ?></label>
                                <input type="text" name="l_name" class="form-control" placeholder="<?php echo e(translate('last')); ?> <?php echo e(translate('name')); ?>"
                                       required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('email')); ?></label>
                                <input type="email" name="email" class="form-control" placeholder="<?php echo e(translate('Ex : ex@example.com')); ?>"
                                       required>
                            </div>
                        </div>
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('phone')); ?></label>
                                <input type="text" name="phone" class="form-control" placeholder="<?php echo e(translate('Ex : 017********')); ?>"
                                       required>
                            </div>
                        </div>
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('branch')); ?></label>
                                <select name="branch_id" class="form-control">
                                    <option value="0"><?php echo e(translate('all')); ?></option>
                                    <?php $__currentLoopData = \App\Model\Branch::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($branch['id']); ?>"><?php echo e($branch['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('identity')); ?> <?php echo e(translate('type')); ?></label>
                                <select name="identity_type" class="form-control">
                                    <option value="passport"><?php echo e(translate('passport')); ?></option>
                                    <option value="driving_license"><?php echo e(translate('driving')); ?> <?php echo e(translate('license')); ?></option>
                                    <option value="nid"><?php echo e(translate('nid')); ?></option>
                                    <option value="restaurant_id"><?php echo e(translate('restaurant')); ?> <?php echo e(translate('id')); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('identity')); ?> <?php echo e(translate('number')); ?></label>
                                <input type="text" name="identity_number" class="form-control"
                                       placeholder="<?php echo e(translate('Ex : DH-23434-LS')); ?>"
                                       required>
                            </div>
                        </div>
                        <div class="col-md-12 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('identity')); ?> <?php echo e(translate('image')); ?></label>
                                <div>
                                    <div class="row" id="coba"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('password')); ?></label>
                        <input type="text" name="password" class="form-control" placeholder="<?php echo e(translate('Ex : password')); ?>"
                               required>
                    </div>

                    <div class="form-group">
                        <label><?php echo e(translate('deliveryman')); ?> <?php echo e(translate('image')); ?></label><small style="color: red">* ( <?php echo e(translate('ratio')); ?> 1:1 )</small>
                        <div class="custom-file">
                            <input type="file" name="image" id="customFileEg1" class="custom-file-input"
                                   accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*" required>
                            <label class="custom-file-label" for="customFileEg1"><?php echo e(translate('choose')); ?> <?php echo e(translate('file')); ?></label>
                        </div>
                        <hr>
                        <center>
                            <img style="height: 200px;border: 1px solid; border-radius: 10px;" id="viewer"
                                 src="<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>" alt="delivery-man image"/>
                        </center>
                    </div>
                    <hr>
                    <button type="submit" class="btn btn-primary"><?php echo e(translate('submit')); ?></button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>

    <script src="<?php echo e(asset('public/assets/admin/js/spartan-multi-image-picker.js')); ?>"></script>
    <script type="text/javascript">
        $(function () {
            $("#coba").spartanMultiImagePicker({
                fieldName: 'identity_image[]',
                maxCount: 5,
                rowHeight: '120px',
                groupClassName: 'col-2',
                maxFileSize: '',
                placeholderImage: {
                    image: '<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>',
                    width: '100%'
                },
                dropFileLabel: "Drop Here",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('<?php echo e(\App\CentralLogics\translate("Please only input png or jpg type file")); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('<?php echo e(\App\CentralLogics\translate("File size too big")); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/delivery-man/index.blade.php ENDPATH**/ ?>