<?php $__env->startSection('title', translate('Deliveryman List')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0 row">
                    <div class="col-12 col-sm-6">
                        <h1 class="page-header-title"><i class="tio-filter-list"></i> <?php echo e(translate('deliveryman')); ?> <?php echo e(translate('list')); ?></h1>
                    </div>

                    <div class="col-12 col-sm-6 text-sm-right text-left">
                        <a href="<?php echo e(route('admin.delivery-man.add')); ?>" class="btn btn-primary pull-right"><i
                                class="tio-add-circle"></i> <?php echo e(translate('add Deliveryman')); ?></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <!-- Card -->
                <div class="card">
                    <!-- Header -->
                    <div class="card-header flex-between">
                        <div class="flex-start">
                            <h5 class="card-header-title"><?php echo e(translate('Delivery Man Table')); ?></h5>
                            <h5 class="card-header-title text-primary mx-1">(<?php echo e($delivery_men->total()); ?>)</h5>
                        </div>
                        <div>
                            <form action="<?php echo e(url()->current()); ?>" method="GET">
                                <div class="input-group">
                                    <input id="datatableSearch_" type="search" name="search"
                                           class="form-control"
                                           placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                           value="<?php echo e($search); ?>" required autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- End Header -->

                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('#')); ?></th>
                                <th style="width: 30%"><?php echo e(translate('name')); ?></th>
                                <th style="width: 25%"><?php echo e(translate('image')); ?></th>
                                <th><?php echo e(translate('email')); ?></th>
                                <th><?php echo e(translate('phone')); ?></th>
                                <th><?php echo e(translate('action')); ?></th>
                            </tr>
                            </thead>

                            <tbody id="set-rows">
                            <?php $__currentLoopData = $delivery_men; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($delivery_men->firstitem()+$key); ?></td>
                                    <td>
                                        <span class="d-block font-size-sm text-body">
                                            <?php echo e($dm['f_name'].' '.$dm['l_name']); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div style="height: 60px; width: 60px; overflow-x: hidden;overflow-y: hidden">
                                            <img width="60" style="border-radius: 50%"
                                                 onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                                 src="<?php echo e(asset('storage/app/public/delivery-man')); ?>/<?php echo e($dm['image']); ?>">
                                        </div>
                                        
                                    </td>
                                    <td>
                                        <?php echo e($dm['phone']); ?>

                                    </td>
                                    <td>
                                        <?php echo e($dm['email']); ?>

                                    </td>
                                    <td>
                                        <!-- Dropdown -->
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                <i class="tio-settings"></i>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item"
                                                   href="<?php echo e(route('admin.delivery-man.edit',[$dm['id']])); ?>"><?php echo e(translate('edit')); ?></a>
                                                <a class="dropdown-item" href="javascript:"
                                                   onclick="form_alert('delivery-man-<?php echo e($dm['id']); ?>','Want to remove this information ?')"><?php echo e(translate('delete')); ?></a>
                                                <form action="<?php echo e(route('admin.delivery-man.delete',[$dm['id']])); ?>"
                                                      method="post" id="delivery-man-<?php echo e($dm['id']); ?>">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                </form>
                                            </div>
                                        </div>
                                        <!-- End Dropdown -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="page-area">
                            <table>
                                <tfoot>
                                <?php echo $delivery_men->links(); ?>

                                </tfoot>
                            </table>
                        </div>

                    </div>
                    <!-- End Table -->
                </div>
                <!-- End Card -->
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        $('#search-form').on('submit', function () {
            var formData = new FormData(this);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.delivery-man.search')); ?>',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    $('#loading').show();
                },
                success: function (data) {
                    $('#set-rows').html(data.view);
                    $('.page-area').hide();
                },
                complete: function () {
                    $('#loading').hide();
                },
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/delivery-man/list.blade.php ENDPATH**/ ?>