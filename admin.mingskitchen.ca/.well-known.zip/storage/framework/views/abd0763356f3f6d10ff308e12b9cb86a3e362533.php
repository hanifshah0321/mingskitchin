<?php $__env->startSection('title', translate('Customer Details')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="d-print-none pb-2">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-no-gutter">
                            <li class="breadcrumb-item">
                                <a class="breadcrumb-link"
                                   href="<?php echo e(route('admin.customer.list')); ?>">
                                    <?php echo e(translate('customers')); ?>

                                </a>
                            </li>
                            <li class="breadcrumb-item active"
                                aria-current="page"><?php echo e(translate('customer')); ?> <?php echo e(translate('details')); ?></li>
                        </ol>
                    </nav>

                    <div class="d-sm-flex align-items-sm-center">
                        <h1 class="page-header-title"><?php echo e(translate('customer')); ?> <?php echo e(translate('id')); ?>

                            #<?php echo e($customer['id']); ?></h1>
                        <span class="ml-2 ml-sm-3">
                        <i class="tio-date-range">
                        </i> <?php echo e(translate('joined_at')); ?> : <?php echo e(date('d M Y H:i:s',strtotime($customer['created_at']))); ?>

                        </span>
                    </div>
                    <div class="row border-top pt-3">
                        <div class="col-12">
                            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
                                <i class="tio-home-outlined"></i> <?php echo e(translate('dashboard')); ?>

                            </a>

                        </div>
                    </div>
                </div>

                <div class="col-sm-auto">
                    <a class="btn btn-icon btn-sm btn-ghost-secondary rounded-circle mr-1"
                       href="<?php echo e(route('admin.customer.view',[$customer['id']-1])); ?>"
                       data-toggle="tooltip" data-placement="top" title="Previous customer">
                        <i class="tio-arrow-backward"></i>
                    </a>
                    <a class="btn btn-icon btn-sm btn-ghost-secondary rounded-circle"
                       href="<?php echo e(route('admin.customer.view',[$customer['id']+1])); ?>" data-toggle="tooltip"
                       data-placement="top" title="Next customer">
                        <i class="tio-arrow-forward"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- End Page Header -->

        <div class="row" id="printableArea">
            <div class="col-lg-8 mb-3 mb-lg-0">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-header-title">
                            <strong><?php echo e(translate('current')); ?> <?php echo e(translate('point')); ?>

                                : <?php echo e($customer['point']); ?></strong>
                            <button class="btn btn-outline-primary btn-sm" data-toggle="modal"
                                    data-target=".point-example-modal-sm">
                                <?php echo e(translate('add')); ?> <?php echo e(translate('point')); ?>

                            </button>
                        </h5>
                        <h6 class="" style="color: #8a8a8a;">
                            <a class="text-capitalize btn btn-primary" href="<?php echo e(route('admin.customer.customer_transaction',[$customer['id']])); ?>">
                                <?php echo e(translate('point')); ?> <?php echo e(translate('history')); ?>

                            </a>
                        </h6>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table id="columnSearchDatatable"
                               class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                               data-hs-datatables-options='{
                                 "order": [],
                                 "orderCellsTop": true
                               }'>
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('#')); ?></th>
                                <th style="width: 50%"
                                    class="text-center"><?php echo e(translate('order')); ?> <?php echo e(translate('id')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('total')); ?></th>
                                <th style="width: 10%"><?php echo e(translate('action')); ?></th>
                            </tr>
                            <tr>
                                <th></th>
                                <th>
                                    <input type="text" id="column1_search" class="form-control form-control-sm"
                                           placeholder="<?php echo e(translate('Search Order ID')); ?>">
                                </th>
                                <th></th>
                                <th>
                                    
                                </th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td class="table-column-pl-0 text-center">
                                        <a href="<?php echo e(route('admin.orders.details',['id'=>$order['id']])); ?>"><?php echo e($order['id']); ?></a>
                                    </td>
                                    <td><?php echo e(\App\CentralLogics\Helpers::set_symbol($order['order_amount'])); ?></td>
                                    <td>
                                        <!-- Dropdown -->
                                        <div class="dropdown">
                                            <button class="btn btn-outline-secondary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                <i class="tio-settings"></i>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item"
                                                   href="<?php echo e(route('admin.orders.details',['id'=>$order['id']])); ?>"><i
                                                        class="tio-visible"></i> <?php echo e(translate('view')); ?></a>
                                                <a class="dropdown-item" target="_blank"
                                                   href="<?php echo e(route('admin.orders.generate-invoice',[$order['id']])); ?>"><i
                                                        class="tio-download"></i> <?php echo e(translate('invoice')); ?></a>
                                            </div>
                                        </div>
                                        <!-- End Dropdown -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- Footer -->
                        <div class="card-footer">
                            <!-- Pagination -->
                        <?php echo $orders->links(); ?>

                        <!-- End Pagination -->
                        </div>
                        <!-- End Footer -->
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <!-- Card -->
                <div class="card">
                    <!-- Header -->
                    <div class="card-header">
                        <h4 class="card-header-title"><?php echo e(translate('customer')); ?></h4>
                    </div>
                    <!-- End Header -->

                    <!-- Body -->
                    <?php if($customer): ?>
                        <div class="card-body">
                            <div class="media align-items-center" href="javascript:">
                                <div class="avatar avatar-circle mr-3">
                                    <img
                                        class="avatar-img"
                                        onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                        src="<?php echo e(asset('storage/app/public/profile/'.$customer->image)); ?>"
                                        alt="Image Description">
                                </div>
                                <div class="media-body">
                                <span
                                    class="text-body text-hover-primary"><?php echo e($customer['f_name'].' '.$customer['l_name']); ?></span>

                                </div>
                                <div class="media-body text-right">
                                    
                                </div>
                            </div>
                            <hr>
                            <div class="media align-items-center" href="javascript:">
                                <div class="icon icon-soft-info icon-circle mr-3">
                                    <i class="tio-shopping-basket-outlined"></i>
                                </div>
                                <div class="media-body">
                                    <span
                                        class="text-body text-hover-primary"><?php echo e($customer->orders->count()); ?> <?php echo e(translate('orders')); ?></span>
                                </div>
                                <div class="media-body text-right">
                                    
                                </div>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-between align-items-center">
                                <h5><?php echo e(translate('contact')); ?> <?php echo e(translate('info')); ?></h5>
                            </div>

                            <ul class="list-unstyled list-unstyled-py-2">
                                <li>
                                    <i class="tio-online mr-2"></i>
                                    <?php echo e($customer['email']); ?>

                                </li>
                                <li>
                                    <i class="tio-android-phone-vs mr-2"></i>
                                    <?php echo e($customer['phone']); ?>

                                </li>
                            </ul>

                            <div class="d-flex justify-content-between align-items-center">
                                <h5><?php echo e(translate('addresses')); ?></h5>
                            </div>

                            <?php $__currentLoopData = $customer->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul class="list-unstyled list-unstyled-py-2">
                                    <li>
                                        <i class="tio-tab mr-2"></i>
                                        <?php echo e($address['address_type']); ?>

                                    </li>
                                    <li>
                                        <i class="tio-android-phone-vs mr-2"></i>
                                        <?php echo e($address['contact_person_umber']); ?>

                                    </li>
                                    <li style="cursor: pointer">
                                        <a target="_blank"
                                           href="http://maps.google.com/maps?z=12&t=m&q=loc:<?php echo e($address['latitude']); ?>+<?php echo e($address['longitude']); ?>">
                                            <i class="tio-map mr-2"></i>
                                            <?php echo e($address['address']); ?>

                                        </a>
                                    </li>
                                </ul>
                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                <?php endif; ?>
                <!-- End Body -->
                </div>
                <!-- End Card -->
            </div>
        </div>
        <!-- End Row -->
    </div>
    <div class="modal fade point-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <h5 class="modal-title h4" id="mySmallModalLabel"> <?php echo e(translate('add')); ?> <?php echo e(translate('point')); ?> </h5>
                    <button type="button" class="btn btn-xs btn-icon btn-ghost-secondary" data-dismiss="modal"
                            aria-label="Close">
                        <i class="tio-clear tio-lg"></i>
                    </button>
                </div>

                <form action="<?php echo e(route('admin.customer.AddPoint',[$customer['id']])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <!-- Input Group -->
                        <div class="form-group">
                            <input type="number" name="point" class="form-control"
                                   placeholder="EX : 100" required>
                        </div>
                        <!-- End Input Group -->
                        <button class="btn btn-primary"><?php echo e(translate('submit')); ?></button>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

    <script>
        $(document).on('ready', function () {
            // INITIALIZATION OF DATATABLES
            // =======================================================
            // var datatable = $.HSCore.components.HSDatatables.init($('#columnSearchDatatable'));

            var datatable = $('.table').DataTable({
                "paging": false
            });
            $('#column1_search').on('keyup', function () {
                datatable
                    .columns(1)
                    .search(this.value)
                    .draw();
            });


            $('#column3_search').on('change', function () {
                datatable
                    .columns(2)
                    .search(this.value)
                    .draw();
            });


            // INITIALIZATION OF SELECT2
            // =======================================================
            $('.js-select2-custom').each(function () {
                var select2 = $.HSCore.components.HSSelect2.init($(this));
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/customer/customer-view.blade.php ENDPATH**/ ?>