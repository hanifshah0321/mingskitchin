<?php $__env->startSection('title', translate('Add new branch')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i
                            class="tio-add-circle-outlined"></i> <?php echo e(translate('add New Branch')); ?>

                    </h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(route('admin.branch.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('name')); ?></label>
                                <input type="text" name="name" class="form-control" maxlength="255"
                                       placeholder="<?php echo e(translate('New branch')); ?>" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('email')); ?></label>
                                <input type="email" name="email" class="form-control" maxlength="255"
                                       placeholder="<?php echo e(translate('EX : example@example.com')); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-5">
                            <div class="form-group">
                                <label class="input-label" for=""><?php echo e(translate('latitude')); ?></label>
                                <input type="number" step="any" name="latitude" class="form-control" maxlength="255"
                                       placeholder="<?php echo e(translate('Ex : -132.44442')); ?>"
                                       required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-5">
                            <div class="form-group">
                                <label class="input-label" for=""><?php echo e(translate('longitude')); ?></label>
                                <input type="number" step="any" name="longitude" class="form-control" maxlength="255"
                                       placeholder="<?php echo e(translate('Ex : 94.233')); ?>"
                                       required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-2">
                            <div class="form-group">
                                <label class="input-label" for="">
                                    <i class="tio-info-outined"
                                       data-toggle="tooltip"
                                       data-placement="top"
                                       title="<?php echo e(translate('This value is the radius from your restaurant location, and customer can order food inside  the circle calculated by this radius.')); ?>"></i>
                                    <?php echo e(translate('coverage (km)')); ?>

                                </label>
                                <input type="number" name="coverage" min="1" max="1000" class="form-control"
                                       placeholder="<?php echo e(translate('Ex : 3')); ?>"
                                       required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="input-label" for=""><?php echo e(translate('address')); ?></label>
                                <input type="text" name="address" class="form-control" placeholder="" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('password')); ?></label>
                                <input type="text" name="password" class="form-control" placeholder="<?php echo e(translate('Password')); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><?php echo e(translate('Branch Image')); ?></label><small style="color: red">* ( <?php echo e(translate('ratio')); ?> 1:1 )</small>
                        <div class="custom-file">
                            <input type="file" name="image" id="customFileEg1" class="custom-file-input" value="<?php echo e(old('image')); ?>"
                                   accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*" required>
                            <label class="custom-file-label" for="customFileEg1"><?php echo e(translate('Choose File')); ?></label>
                        </div>
                        <div class="text-center mt-2">
                            <img style="height: 200px;border: 1px solid; border-radius: 10px;" id="viewer"
                                 src="<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>" alt="branch image"/>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(translate('submit')); ?></button>
                </form>
            </div>

            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 mt-2">
                <div class="card">
                    <!-- Page Header -->
                    <div class="page-header p-2">
                        <div class="row align-items-center">
                            <div class="col-sm mb-2 mb-sm-0">
                                <h1 class="page-header-title"><i
                                        class="tio-filter-list"></i> <?php echo e(translate('Branch List')); ?>

                                    <span class="text-primary">(<?php echo e($branches->total()); ?>)</span></h1>
                            </div>
                        </div>
                    </div>
                    <!-- End Page Header -->
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table
                            class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('#')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('image')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('name')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('email')); ?></th>
                                <th style="width: 10%"><?php echo e(translate('action')); ?></th>
                            </tr>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($branches->firstItem()+$key); ?></td>
                                    <td>
                                        <img class="" height="60px" width="60px"
                                             onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'"
                                             src="<?php echo e(asset('storage/app/public/branch')); ?>/<?php echo e($branch['image']); ?>">
                                    </td>
                                    <td>
                                    <span class="d-block font-size-sm text-body">
                                        <?php echo e($branch['name']); ?> <?php if($branch['id']==1): ?>
                                            <label
                                                class="badge badge-danger"><?php echo e(translate('main')); ?></label>
                                        <?php else: ?>
                                            <label
                                                class="badge badge-info"><?php echo e(translate('sub')); ?></label>
                                        <?php endif; ?>
                                    </span>
                                    </td>
                                    <td><?php echo e($branch['email']); ?></td>
                                    <td>
                                    <?php if(env('APP_MODE')!='demo' || $branch['id']!=1): ?>
                                        <!-- Dropdown -->
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button"
                                                        id="dropdownMenuButton" data-toggle="dropdown"
                                                        aria-haspopup="true"
                                                        aria-expanded="false">
                                                    <i class="tio-settings"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <a class="dropdown-item"
                                                       href="<?php echo e(route('admin.branch.edit',[$branch['id']])); ?>"><?php echo e(translate('edit')); ?></a>
                                                    <?php if($branch['id']!=1): ?>
                                                        <a class="dropdown-item" href="javascript:"
                                                           onclick="form_alert('branch-<?php echo e($branch['id']); ?>','Want to delete this branch ?')"><?php echo e(translate('delete')); ?></a>
                                                        <form action="<?php echo e(route('admin.branch.delete',[$branch['id']])); ?>"
                                                              method="post" id="branch-<?php echo e($branch['id']); ?>">
                                                            <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <!-- End Dropdown -->
                                        <?php else: ?>
                                            <label class="badge badge-danger"><?php echo e(translate('Not Permitted')); ?></label>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <table>
                            <tfoot>
                            <?php echo $branches->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deelbnol/admin.mingskitchen.ca/resources/views/admin-views/branch/index.blade.php ENDPATH**/ ?>