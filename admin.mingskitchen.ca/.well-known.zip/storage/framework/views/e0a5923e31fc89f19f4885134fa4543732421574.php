<?php $__env->startSection('title', translate('Product List')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i
                            class="tio-filter-list"></i> <?php echo e(translate('product')); ?> <?php echo e(translate('list')); ?> <span class="text-primary">(<?php echo e($products->total()); ?>)</span></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <!-- Card -->
                <div class="card">
                    <!-- Header -->
                    <div class="card-header">
                        <div class="row" style="width: 100%">
                            <div class="col-12 col-md-3 mb-1 mb-md-0">
                                <form action="<?php echo e(url()->current()); ?>" method="GET">
                                    <div class="input-group">
                                        <input id="datatableSearch_" type="search" name="search"
                                               class="form-control"
                                               placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                               value="<?php echo e($search); ?>" required autocomplete="off">
                                        <div class="input-group-append">
                                            <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-0 col-sm-0 col-md-6"></div>
                            <div class="col-12 col-md-3">
                                <a href="<?php echo e(route('admin.product.add-new')); ?>" class="btn btn-primary pull-right btn-block"><i
                                        class="tio-add-circle"></i> <?php echo e(translate('add')); ?> <?php echo e(translate('product')); ?></a>
                            </div>
                        </div>
                    </div>
                    <!-- End Header -->

                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('#')); ?></th>
                                <th style="width: 30%"><?php echo e(translate('name')); ?></th>
                                <th style="width: 25%"><?php echo e(translate('image')); ?></th>
                                <th><?php echo e(translate('status')); ?></th>
                                <th><?php echo e(translate('price')); ?></th>
                                <th><?php echo e(translate('action')); ?></th>
                            </tr>
                            </thead>

                            <tbody id="set-rows">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($products->firstitem()+$key); ?></td>
                                    <td>
                                        <span class="d-block font-size-sm text-body">
                                             <a href="<?php echo e(route('admin.product.view',[$product['id']])); ?>">
                                               <?php echo e(Str::limit($product['name'], 30)); ?>

                                             </a>
                                        </span>
                                    </td>
                                    <td>
                                        <div style="height: 100px; width: 100px; overflow-x: hidden;overflow-y: hidden">
                                            <img src="<?php echo e(asset('storage/app/public/product')); ?>/<?php echo e($product['image']); ?>"
                                                 style="width: 100px"
                                                 onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'">
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($product['status']==1): ?>
                                            <div style="padding: 10px;border: 1px solid;cursor: pointer"
                                                 onclick="location.href='<?php echo e(route('admin.product.status',[$product['id'],0])); ?>'">
                                                <span
                                                    class="legend-indicator bg-success"></span><?php echo e(translate('active')); ?>

                                            </div>
                                        <?php else: ?>
                                            <div style="padding: 10px;border: 1px solid;cursor: pointer"
                                                 onclick="location.href='<?php echo e(route('admin.product.status',[$product['id'],1])); ?>'">
                                                <span
                                                    class="legend-indicator bg-danger"></span><?php echo e(translate('disabled')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(\App\CentralLogics\Helpers::set_symbol($product['price'])); ?></td>
                                    <td>
                                        <!-- Dropdown -->
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                <i class="tio-settings"></i>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item"
                                                   href="<?php echo e(route('admin.product.edit',[$product['id']])); ?>"><?php echo e(translate('edit')); ?></a>
                                                <a class="dropdown-item" href="javascript:"
                                                   onclick="form_alert('product-<?php echo e($product['id']); ?>','Want to delete this item ?')"><?php echo e(translate('delete')); ?></a>
                                                <form action="<?php echo e(route('admin.product.delete',[$product['id']])); ?>"
                                                      method="post" id="product-<?php echo e($product['id']); ?>">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                </form>
                                            </div>
                                        </div>
                                        <!-- End Dropdown -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <hr>
                        <div class="page-area">
                            <table>
                                <tfoot class="border-top">
                                <?php echo $products->links(); ?>

                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <!-- End Table -->
                </div>
                <!-- End Card -->
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        $('#search-form').on('submit', function () {
            var formData = new FormData(this);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.product.search')); ?>',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    $('#loading').show();
                },
                success: function (data) {
                    $('#set-rows').html(data.view);
                    $('.page-area').hide();
                },
                complete: function () {
                    $('#loading').hide();
                },
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ming's\resources\views/admin-views/product/list.blade.php ENDPATH**/ ?>