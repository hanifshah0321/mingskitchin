<?php

return [
    'razor_key' => env('RAZOR_KEY',''),
    'razor_secret' => env('RAZOR_SECRET','')
];
